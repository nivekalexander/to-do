import {
  a,
  c,
  i,
  o,
  r
} from "./chunk-I5FGWB6R.js";
import "./chunk-2SCNBYQ2.js";
import "./chunk-YAS4LRVC.js";
import "./chunk-NB53XM2W.js";
export {
  c as MENU_BACK_BUTTON_PRIORITY,
  a as OVERLAY_BACK_BUTTON_PRIORITY,
  i as blockHardwareBackButton,
  o as shouldUseCloseWatcher,
  r as startHardwareBackButton
};
//# sourceMappingURL=p-Bz0dSlXZ-2G2VXR34.js.map
