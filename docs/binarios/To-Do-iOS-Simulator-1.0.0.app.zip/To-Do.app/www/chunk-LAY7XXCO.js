import {
  ChangeDetectionStrategy,
  Component,
  Injectable,
  Input,
  IonIcon,
  RouterLink,
  RouterLinkActive,
  TODO_REPOSITORY,
  computed,
  createInitialTodoState,
  inject,
  input,
  setClassMetadata,
  signal,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdomElementEnd,
  ɵɵdomElementStart,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵtext,
  ɵɵtextInterpolate
} from "./chunk-DSNEALCX.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-NB53XM2W.js";

// node_modules/ionicons/dist/esm-es5/utils-2c56d1c8.js
var CACHED_MAP;
var getIconMap = function() {
  if (typeof window === "undefined") {
    return /* @__PURE__ */ new Map();
  } else {
    if (!CACHED_MAP) {
      var t = window;
      t.Ionicons = t.Ionicons || {};
      CACHED_MAP = t.Ionicons.map = t.Ionicons.map || /* @__PURE__ */ new Map();
    }
    return CACHED_MAP;
  }
};
var addIcons = function(t) {
  Object.keys(t).forEach((function(e) {
    addToIconMap(e, t[e]);
    var r = e.replace(/([a-z0-9]|(?=[A-Z]))([A-Z0-9])/g, "$1-$2").toLowerCase();
    if (e !== r) {
      addToIconMap(r, t[e]);
    }
  }));
};
var addToIconMap = function(t, e) {
  var r = getIconMap();
  var n = r.get(t);
  if (n === void 0) {
    r.set(t, e);
  } else if (n !== e) {
    console.warn('[Ionicons Warning]: Multiple icons were mapped to name "'.concat(t, '". Ensure that multiple icons are not mapped to the same icon name.'));
  }
};

// node_modules/ionicons/icons/index.mjs
var add = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' d='M256 112v288M400 256H112' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
var checkmark = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' d='M416 128L192 384l-96-96' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
var checkmarkCircleOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M448 256c0-106-86-192-192-192S64 150 64 256s86 192 192 192 192-86 192-192z' stroke-miterlimit='10' class='ionicon-fill-none ionicon-stroke-width'/><path stroke-linecap='round' stroke-linejoin='round' d='M352 176L217.6 336 160 272' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
var clipboardOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M336 64h32a48 48 0 0148 48v320a48 48 0 01-48 48H144a48 48 0 01-48-48V112a48 48 0 0148-48h32' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/><rect x='176' y='32' width='160' height='64' rx='26.13' ry='26.13' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
var closeOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' d='M368 368L144 144M368 144L144 368' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
var ellipsisVertical = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><circle cx='256' cy='256' r='48'/><circle cx='256' cy='416' r='48'/><circle cx='256' cy='96' r='48'/></svg>";
var fileTrayOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M384 80H128c-26 0-43 14-48 40L48 272v112a48.14 48.14 0 0048 48h320a48.14 48.14 0 0048-48V272l-32-152c-5-27-23-40-48-40z' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/><path stroke-linecap='round' stroke-linejoin='round' d='M48 272h144M320 272h144M192 272a64 64 0 00128 0' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
var folderOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M440 432H72a40 40 0 01-40-40V120a40 40 0 0140-40h75.89a40 40 0 0122.19 6.72l27.84 18.56a40 40 0 0022.19 6.72H440a40 40 0 0140 40v240a40 40 0 01-40 40zM32 192h448' stroke-linecap='round' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
var listOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' d='M160 144h288M160 256h288M160 368h288' class='ionicon-fill-none ionicon-stroke-width'/><circle cx='80' cy='144' r='16' stroke-linecap='round' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/><circle cx='80' cy='256' r='16' stroke-linecap='round' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/><circle cx='80' cy='368' r='16' stroke-linecap='round' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
var optionsOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path stroke-linecap='round' stroke-linejoin='round' d='M368 128h80M64 128h240M368 384h80M64 384h240M208 256h240M64 256h80' class='ionicon-fill-none ionicon-stroke-width'/><circle cx='336' cy='128' r='32' stroke-linecap='round' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/><circle cx='176' cy='256' r='32' stroke-linecap='round' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/><circle cx='336' cy='384' r='32' stroke-linecap='round' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
var syncOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M434.67 285.59v-29.8c0-98.73-80.24-178.79-179.2-178.79a179 179 0 00-140.14 67.36m-38.53 82v29.8C76.8 355 157 435 256 435a180.45 180.45 0 00140-66.92' stroke-linecap='round' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/><path stroke-linecap='round' stroke-linejoin='round' d='M32 256l44-44 46 44M480 256l-44 44-46-44' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
var timeOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M256 64C150 64 64 150 64 256s86 192 192 192 192-86 192-192S362 64 256 64z' stroke-miterlimit='10' class='ionicon-fill-none ionicon-stroke-width'/><path stroke-linecap='round' stroke-linejoin='round' d='M256 128v144h96' class='ionicon-fill-none ionicon-stroke-width'/></svg>";
var trashOutline = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' class='ionicon' viewBox='0 0 512 512'><path d='M112 112l20 320c.95 18.49 14.4 32 32 32h184c17.67 0 30.87-13.51 32-32l20-320' stroke-linecap='round' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/><path stroke-linecap='round' stroke-miterlimit='10' d='M80 112h352' class='ionicon-stroke-width'/><path d='M192 112V72h0a23.93 23.93 0 0124-24h80a23.93 23.93 0 0124 24h0v40M256 176v224M184 176l8 224M328 176l-8 224' stroke-linecap='round' stroke-linejoin='round' class='ionicon-fill-none ionicon-stroke-width'/></svg>";

// src/app/core/layout/app-header/app-header.component.ts
var _AppHeaderComponent = class _AppHeaderComponent {
  constructor() {
    this.title = input("To-Do", ...ngDevMode ? [{ debugName: "title" }] : []);
  }
};
_AppHeaderComponent.\u0275fac = function AppHeaderComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AppHeaderComponent)();
};
_AppHeaderComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AppHeaderComponent, selectors: [["app-header"]], inputs: { title: [1, "title"] }, decls: 3, vars: 1, consts: [[1, "header-content"]], template: function AppHeaderComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "div", 0)(1, "h1");
    \u0275\u0275text(2);
    \u0275\u0275domElementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.title());
  }
}, styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n}\n.header-content[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  box-sizing: border-box;\n  width: 100%;\n  padding: 16px 20px;\n}\nh1[_ngcontent-%COMP%] {\n  margin: 0;\n  color: #ffffff;\n  font-size: 1.4rem;\n  font-weight: 700;\n  line-height: 1.2;\n  letter-spacing: 0.01em;\n  text-align: center;\n}\n/*# sourceMappingURL=app-header.component.css.map */"], changeDetection: 0 });
var AppHeaderComponent = _AppHeaderComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AppHeaderComponent, [{
    type: Component,
    args: [{ selector: "app-header", standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: '<div class="header-content">\n  <h1>{{ title() }}</h1>\n</div>\n', styles: ["/* src/app/core/layout/app-header/app-header.component.scss */\n:host {\n  display: block;\n}\n.header-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  box-sizing: border-box;\n  width: 100%;\n  padding: 16px 20px;\n}\nh1 {\n  margin: 0;\n  color: #ffffff;\n  font-size: 1.4rem;\n  font-weight: 700;\n  line-height: 1.2;\n  letter-spacing: 0.01em;\n  text-align: center;\n}\n/*# sourceMappingURL=app-header.component.css.map */\n"] }]
  }], null, { title: [{ type: Input, args: [{ isSignal: true, alias: "title", required: false }] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AppHeaderComponent, { className: "AppHeaderComponent", filePath: "app/core/layout/app-header/app-header.component.ts", lineNumber: 14 });
})();

// src/app/core/layout/bottom-navigation/bottom-navigation.component.ts
var _c0 = () => ({ exact: true });
var _BottomNavigationComponent = class _BottomNavigationComponent {
  constructor() {
    addIcons({
      folderOutline,
      listOutline
    });
  }
};
_BottomNavigationComponent.\u0275fac = function BottomNavigationComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _BottomNavigationComponent)();
};
_BottomNavigationComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _BottomNavigationComponent, selectors: [["app-bottom-navigation"]], decls: 9, vars: 4, consts: [["aria-label", "Navegacion principal"], ["routerLink", "/tasks", "routerLinkActive", "active", 3, "routerLinkActiveOptions"], ["name", "list-outline"], ["routerLink", "/categories", "routerLinkActive", "active", 3, "routerLinkActiveOptions"], ["name", "folder-outline"]], template: function BottomNavigationComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "nav", 0)(1, "a", 1);
    \u0275\u0275element(2, "ion-icon", 2);
    \u0275\u0275elementStart(3, "span");
    \u0275\u0275text(4, "Tareas");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "a", 3);
    \u0275\u0275element(6, "ion-icon", 4);
    \u0275\u0275elementStart(7, "span");
    \u0275\u0275text(8, "Categorias");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275property("routerLinkActiveOptions", \u0275\u0275pureFunction0(2, _c0));
    \u0275\u0275advance(4);
    \u0275\u0275property("routerLinkActiveOptions", \u0275\u0275pureFunction0(3, _c0));
  }
}, dependencies: [
  RouterLink,
  RouterLinkActive,
  IonIcon
], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  background: #ffffff;\n}\nnav[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  box-sizing: border-box;\n  width: 100%;\n  padding: 16px 0;\n  background: #ffffff;\n}\na[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  min-width: 0;\n  padding: 0;\n  color: #8a94a6;\n  line-height: 1;\n  text-align: center;\n  text-decoration: none;\n}\na[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  width: 24px;\n  height: 24px;\n  margin: 0;\n  font-size: 24px;\n}\na[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  line-height: 1.2;\n  text-align: center;\n}\na.active[_ngcontent-%COMP%] {\n  color: #1769e8;\n}\n/*# sourceMappingURL=bottom-navigation.component.css.map */"], changeDetection: 0 });
var BottomNavigationComponent = _BottomNavigationComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BottomNavigationComponent, [{
    type: Component,
    args: [{ selector: "app-bottom-navigation", standalone: true, imports: [
      RouterLink,
      RouterLinkActive,
      IonIcon
    ], changeDetection: ChangeDetectionStrategy.OnPush, template: '<nav aria-label="Navegacion principal">\n  <a\n    routerLink="/tasks"\n    routerLinkActive="active"\n    [routerLinkActiveOptions]="{ exact: true }"\n  >\n    <ion-icon name="list-outline" />\n    <span>Tareas</span>\n  </a>\n\n  <a\n    routerLink="/categories"\n    routerLinkActive="active"\n    [routerLinkActiveOptions]="{ exact: true }"\n  >\n    <ion-icon name="folder-outline" />\n    <span>Categorias</span>\n  </a>\n</nav>\n', styles: ["/* src/app/core/layout/bottom-navigation/bottom-navigation.component.scss */\n:host {\n  display: block;\n  background: #ffffff;\n}\nnav {\n  display: grid;\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  box-sizing: border-box;\n  width: 100%;\n  padding: 16px 0;\n  background: #ffffff;\n}\na {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  min-width: 0;\n  padding: 0;\n  color: #8a94a6;\n  line-height: 1;\n  text-align: center;\n  text-decoration: none;\n}\na ion-icon {\n  width: 24px;\n  height: 24px;\n  margin: 0;\n  font-size: 24px;\n}\na span {\n  line-height: 1.2;\n  text-align: center;\n}\na.active {\n  color: #1769e8;\n}\n/*# sourceMappingURL=bottom-navigation.component.css.map */\n"] }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(BottomNavigationComponent, { className: "BottomNavigationComponent", filePath: "app/core/layout/bottom-navigation/bottom-navigation.component.ts", lineNumber: 30 });
})();

// src/app/shared/models/task-filter.model.ts
var EMPTY_TASK_FILTERS = {
  categoryId: null,
  status: null
};

// src/app/shared/data-access/todo-store.ts
var _TodoStore = class _TodoStore {
  constructor() {
    this.repository = inject(TODO_REPOSITORY);
    this.state = signal(createInitialTodoState(), ...ngDevMode ? [{ debugName: "state" }] : []);
    this.loadingState = signal(false, ...ngDevMode ? [{ debugName: "loadingState" }] : []);
    this.initializedState = signal(false, ...ngDevMode ? [{ debugName: "initializedState" }] : []);
    this.filtersState = signal(__spreadValues({}, EMPTY_TASK_FILTERS), ...ngDevMode ? [{ debugName: "filtersState" }] : []);
    this.loading = this.loadingState.asReadonly();
    this.initialized = this.initializedState.asReadonly();
    this.filters = this.filtersState.asReadonly();
    this.tasks = computed(() => this.state().tasks, ...ngDevMode ? [{ debugName: "tasks" }] : []);
    this.categories = computed(() => this.state().categories, ...ngDevMode ? [{ debugName: "categories" }] : []);
    this.activeFilterCount = computed(() => {
      const filters = this.filtersState();
      return Number(filters.categoryId !== null) + Number(filters.status !== null);
    }, ...ngDevMode ? [{ debugName: "activeFilterCount" }] : []);
    this.filteredTasks = computed(() => {
      const filters = this.filtersState();
      return this.state().tasks.filter((task) => {
        const matchesCategory = filters.categoryId === null || task.categoryId === filters.categoryId;
        const matchesStatus = filters.status === null || task.status === filters.status;
        return matchesCategory && matchesStatus;
      });
    }, ...ngDevMode ? [{ debugName: "filteredTasks" }] : []);
    this.notStartedTasks = computed(() => this.filteredTasks().filter((task) => task.status === "not-started"), ...ngDevMode ? [{ debugName: "notStartedTasks" }] : []);
    this.inProgressTasks = computed(() => this.filteredTasks().filter((task) => task.status === "in-progress"), ...ngDevMode ? [{ debugName: "inProgressTasks" }] : []);
    this.finishedTasks = computed(() => this.filteredTasks().filter((task) => task.status === "finished"), ...ngDevMode ? [{ debugName: "finishedTasks" }] : []);
    this.pendingCount = computed(() => this.state().tasks.filter((task) => task.status !== "finished").length, ...ngDevMode ? [{ debugName: "pendingCount" }] : []);
    this.completedCount = computed(() => this.state().tasks.filter((task) => task.status === "finished").length, ...ngDevMode ? [{ debugName: "completedCount" }] : []);
  }
  initialize() {
    return __async(this, null, function* () {
      if (this.initializedState() || this.loadingState()) {
        return;
      }
      this.loadingState.set(true);
      try {
        const savedState = yield this.repository.load();
        this.state.set(savedState);
      } finally {
        this.initializedState.set(true);
        this.loadingState.set(false);
      }
    });
  }
  addTask(title, categoryId = null) {
    return __async(this, null, function* () {
      const cleanTitle = title.trim();
      if (!cleanTitle) {
        throw new Error("El titulo es obligatorio.");
      }
      this.validateCategory(categoryId);
      const now = Date.now();
      const task = {
        id: this.createId(),
        title: cleanTitle,
        categoryId,
        status: "not-started",
        createdAt: now,
        updatedAt: now
      };
      yield this.repository.createTask(task);
      this.state.update((currentState) => __spreadProps(__spreadValues({}, currentState), {
        tasks: [
          task,
          ...currentState.tasks
        ]
      }));
    });
  }
  moveTask(taskId, status) {
    return __async(this, null, function* () {
      this.validateStatus(status);
      const task = this.state().tasks.find((currentTask) => currentTask.id === taskId);
      if (!task) {
        throw new Error("La tarea seleccionada no existe.");
      }
      if (task.status === status) {
        return;
      }
      const updatedTask = __spreadProps(__spreadValues({}, task), {
        status,
        updatedAt: Date.now()
      });
      yield this.repository.updateTask(updatedTask);
      this.replaceTask(updatedTask);
    });
  }
  deleteTask(taskId) {
    return __async(this, null, function* () {
      const taskExists = this.state().tasks.some((task) => task.id === taskId);
      if (!taskExists) {
        return;
      }
      yield this.repository.deleteTask(taskId);
      this.state.update((currentState) => __spreadProps(__spreadValues({}, currentState), {
        tasks: currentState.tasks.filter((task) => task.id !== taskId)
      }));
    });
  }
  addCategory(name) {
    return __async(this, null, function* () {
      const cleanName = name.trim();
      if (!cleanName) {
        throw new Error("El nombre es obligatorio.");
      }
      this.validateUniqueCategoryName(cleanName);
      const now = Date.now();
      const category = {
        id: this.createId(),
        name: cleanName,
        createdAt: now,
        updatedAt: now
      };
      yield this.repository.createCategory(category);
      this.state.update((currentState) => __spreadProps(__spreadValues({}, currentState), {
        categories: [
          ...currentState.categories,
          category
        ]
      }));
    });
  }
  updateCategory(categoryId, name) {
    return __async(this, null, function* () {
      const cleanName = name.trim();
      if (!cleanName) {
        throw new Error("El nombre es obligatorio.");
      }
      const category = this.state().categories.find((currentCategory) => currentCategory.id === categoryId);
      if (!category) {
        throw new Error("La categoria seleccionada no existe.");
      }
      this.validateUniqueCategoryName(cleanName, categoryId);
      const updatedCategory = __spreadProps(__spreadValues({}, category), {
        name: cleanName,
        updatedAt: Date.now()
      });
      yield this.repository.updateCategory(updatedCategory);
      this.state.update((currentState) => __spreadProps(__spreadValues({}, currentState), {
        categories: currentState.categories.map((currentCategory) => currentCategory.id === categoryId ? updatedCategory : currentCategory)
      }));
    });
  }
  deleteCategory(categoryId) {
    return __async(this, null, function* () {
      const categoryExists = this.state().categories.some((category) => category.id === categoryId);
      if (!categoryExists) {
        return;
      }
      const now = Date.now();
      const tasksToUpdate = this.state().tasks.filter((task) => task.categoryId === categoryId).map((task) => __spreadProps(__spreadValues({}, task), {
        categoryId: null,
        updatedAt: now
      }));
      yield this.repository.deleteCategory(categoryId, tasksToUpdate);
      const updatedTasksById = new Map(tasksToUpdate.map((task) => [
        task.id,
        task
      ]));
      this.state.update((currentState) => __spreadProps(__spreadValues({}, currentState), {
        categories: currentState.categories.filter((category) => category.id !== categoryId),
        tasks: currentState.tasks.map((task) => updatedTasksById.get(task.id) ?? task)
      }));
      if (this.filtersState().categoryId === categoryId) {
        this.clearFilters();
      }
    });
  }
  setFilters(filters) {
    this.validateCategory(filters.categoryId);
    if (filters.status !== null) {
      this.validateStatus(filters.status);
    }
    this.filtersState.set({
      categoryId: filters.categoryId,
      status: filters.status
    });
  }
  clearFilters() {
    this.filtersState.set(__spreadValues({}, EMPTY_TASK_FILTERS));
  }
  replaceTask(updatedTask) {
    this.state.update((currentState) => __spreadProps(__spreadValues({}, currentState), {
      tasks: currentState.tasks.map((task) => task.id === updatedTask.id ? updatedTask : task)
    }));
  }
  validateCategory(categoryId) {
    if (categoryId === null) {
      return;
    }
    const categoryExists = this.state().categories.some((category) => category.id === categoryId);
    if (!categoryExists) {
      throw new Error("La categoria seleccionada no existe.");
    }
  }
  validateUniqueCategoryName(name, ignoredCategoryId) {
    const normalizedName = name.toLocaleLowerCase();
    const duplicated = this.state().categories.some((category) => category.id !== ignoredCategoryId && category.name.trim().toLocaleLowerCase() === normalizedName);
    if (duplicated) {
      throw new Error("Ya existe una categoria con ese nombre.");
    }
  }
  validateStatus(status) {
    const allowedStatuses = [
      "not-started",
      "in-progress",
      "finished"
    ];
    if (!allowedStatuses.includes(status)) {
      throw new Error("El estado seleccionado no es valido.");
    }
  }
  createId() {
    return globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }
};
_TodoStore.\u0275fac = function TodoStore_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _TodoStore)();
};
_TodoStore.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _TodoStore, factory: _TodoStore.\u0275fac, providedIn: "root" });
var TodoStore = _TodoStore;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TodoStore, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

export {
  addIcons,
  add,
  checkmark,
  checkmarkCircleOutline,
  clipboardOutline,
  closeOutline,
  ellipsisVertical,
  fileTrayOutline,
  optionsOutline,
  syncOutline,
  timeOutline,
  trashOutline,
  AppHeaderComponent,
  BottomNavigationComponent,
  TodoStore
};
//# sourceMappingURL=chunk-LAY7XXCO.js.map
