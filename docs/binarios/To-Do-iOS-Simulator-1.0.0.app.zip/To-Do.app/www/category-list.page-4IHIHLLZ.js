import {
  AppHeaderComponent,
  BottomNavigationComponent,
  TodoStore
} from "./chunk-LAY7XXCO.js";
import {
  ChangeDetectionStrategy,
  Component,
  FormBuilder,
  FormControlName,
  FormGroupDirective,
  Injectable,
  Input,
  IonButton,
  IonContent,
  IonFooter,
  IonHeader,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonSpinner,
  IonText,
  IonToast,
  IonToolbar,
  MaxLengthValidator,
  NgControlStatus,
  NgControlStatusGroup,
  Output,
  ReactiveFormsModule,
  Validators,
  inject,
  input,
  output,
  setClassMetadata,
  signal,
  ɵNgNoValidate,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate
} from "./chunk-DSNEALCX.js";
import "./chunk-23OV75OR.js";
import "./chunk-ZANXXOCD.js";
import "./chunk-SA4GQGRP.js";
import "./chunk-V55YLP36.js";
import "./chunk-B3Y7DSCZ.js";
import "./chunk-I5FGWB6R.js";
import "./chunk-6GY55RSK.js";
import "./chunk-7D2IXJO2.js";
import "./chunk-FZZSIR43.js";
import "./chunk-X4NBNE3H.js";
import "./chunk-PBXPKCK6.js";
import "./chunk-2SCNBYQ2.js";
import "./chunk-YAS4LRVC.js";
import {
  __async
} from "./chunk-NB53XM2W.js";

// src/app/features/categories/components/category-manager/category-manager.component.ts
var _forTrack0 = ($index, $item) => $item.id;
function CategoryManagerComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-text", 4)(1, "p", 8);
    \u0275\u0275text(2, " Escribe un nombre de al menos 2 caracteres. ");
    \u0275\u0275elementEnd()();
  }
}
function CategoryManagerComponent_For_9_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "form", 10);
    \u0275\u0275listener("ngSubmit", function CategoryManagerComponent_For_9_Conditional_1_Template_form_ngSubmit_0_listener() {
      \u0275\u0275restoreView(_r1);
      const category_r2 = \u0275\u0275nextContext().$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.saveCategory(category_r2.id));
    });
    \u0275\u0275element(1, "ion-input", 11);
    \u0275\u0275elementStart(2, "div", 12)(3, "ion-button", 13);
    \u0275\u0275text(4, " Guardar ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "ion-button", 14);
    \u0275\u0275listener("click", function CategoryManagerComponent_For_9_Conditional_1_Template_ion_button_click_5_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.cancelEditing());
    });
    \u0275\u0275text(6, " Cancelar ");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275property("formGroup", ctx_r2.editForm);
    \u0275\u0275advance(3);
    \u0275\u0275property("disabled", ctx_r2.editForm.invalid);
  }
}
function CategoryManagerComponent_For_9_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-label");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "ion-button", 15);
    \u0275\u0275listener("click", function CategoryManagerComponent_For_9_Conditional_2_Template_ion_button_click_2_listener() {
      \u0275\u0275restoreView(_r4);
      const category_r2 = \u0275\u0275nextContext().$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.startEditing(category_r2));
    });
    \u0275\u0275text(3, " Editar ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-button", 16);
    \u0275\u0275listener("click", function CategoryManagerComponent_For_9_Conditional_2_Template_ion_button_click_4_listener() {
      \u0275\u0275restoreView(_r4);
      const category_r2 = \u0275\u0275nextContext().$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.categoryDeleted.emit(category_r2.id));
    });
    \u0275\u0275text(5, " Eliminar ");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const category_r2 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(category_r2.name);
  }
}
function CategoryManagerComponent_For_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-item", 2);
    \u0275\u0275conditionalCreate(1, CategoryManagerComponent_For_9_Conditional_1_Template, 7, 2, "form", 9)(2, CategoryManagerComponent_For_9_Conditional_2_Template, 6, 1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const category_r2 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.editingCategoryId() === category_r2.id ? 1 : 2);
  }
}
function CategoryManagerComponent_ForEmpty_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-item", 7)(1, "ion-label");
    \u0275\u0275text(2, " No hay categorias creadas. ");
    \u0275\u0275elementEnd()();
  }
}
var _CategoryManagerComponent = class _CategoryManagerComponent {
  constructor() {
    this.formBuilder = inject(FormBuilder);
    this.categories = input([], ...ngDevMode ? [{ debugName: "categories" }] : []);
    this.categoryCreated = output();
    this.categoryRenamed = output();
    this.categoryDeleted = output();
    this.editingCategoryId = signal(null, ...ngDevMode ? [{ debugName: "editingCategoryId" }] : []);
    this.createForm = this.formBuilder.nonNullable.group({
      name: [
        "",
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(40)
        ]
      ]
    });
    this.editForm = this.formBuilder.nonNullable.group({
      name: [
        "",
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(40)
        ]
      ]
    });
  }
  createCategory() {
    if (this.createForm.invalid) {
      this.createForm.markAllAsTouched();
      return;
    }
    const name = this.createForm.getRawValue().name;
    this.categoryCreated.emit(name);
    this.createForm.reset({ name: "" });
  }
  startEditing(category) {
    this.editingCategoryId.set(category.id);
    this.editForm.setValue({
      name: category.name
    });
  }
  cancelEditing() {
    this.editingCategoryId.set(null);
    this.editForm.reset({ name: "" });
  }
  saveCategory(categoryId) {
    if (this.editForm.invalid) {
      this.editForm.markAllAsTouched();
      return;
    }
    this.categoryRenamed.emit({
      id: categoryId,
      name: this.editForm.getRawValue().name
    });
    this.cancelEditing();
  }
};
_CategoryManagerComponent.\u0275fac = function CategoryManagerComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _CategoryManagerComponent)();
};
_CategoryManagerComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _CategoryManagerComponent, selectors: [["app-category-manager"]], inputs: { categories: [1, "categories"] }, outputs: { categoryCreated: "categoryCreated", categoryRenamed: "categoryRenamed", categoryDeleted: "categoryDeleted" }, decls: 11, vars: 4, consts: [[1, "category-manager"], [1, "category-form", 3, "ngSubmit", "formGroup"], ["lines", "none"], ["label", "Nueva categoria", "labelPlacement", "stacked", "placeholder", "Ej. Trabajo", "maxlength", "40", "formControlName", "name"], ["color", "danger"], ["expand", "block", "type", "submit", 3, "disabled"], [1, "category-list"], ["lines", "none", 1, "empty-category"], [1, "validation-message"], [1, "edit-form", 3, "formGroup"], [1, "edit-form", 3, "ngSubmit", "formGroup"], ["aria-label", "Nombre de la categoria", "maxlength", "40", "formControlName", "name"], [1, "category-actions"], ["size", "small", "type", "submit", 3, "disabled"], ["size", "small", "fill", "clear", "type", "button", 3, "click"], ["slot", "end", "size", "small", "fill", "clear", 3, "click"], ["slot", "end", "size", "small", "fill", "clear", "color", "danger", 3, "click"]], template: function CategoryManagerComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 0)(1, "form", 1);
    \u0275\u0275listener("ngSubmit", function CategoryManagerComponent_Template_form_ngSubmit_1_listener() {
      return ctx.createCategory();
    });
    \u0275\u0275elementStart(2, "ion-item", 2);
    \u0275\u0275element(3, "ion-input", 3);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(4, CategoryManagerComponent_Conditional_4_Template, 3, 0, "ion-text", 4);
    \u0275\u0275elementStart(5, "ion-button", 5);
    \u0275\u0275text(6, " Crear categoria ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "ion-list", 6);
    \u0275\u0275repeaterCreate(8, CategoryManagerComponent_For_9_Template, 3, 1, "ion-item", 2, _forTrack0, false, CategoryManagerComponent_ForEmpty_10_Template, 3, 0, "ion-item", 7);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275property("formGroup", ctx.createForm);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.createForm.controls.name.touched && ctx.createForm.controls.name.invalid ? 4 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx.createForm.invalid);
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx.categories());
  }
}, dependencies: [
  ReactiveFormsModule,
  \u0275NgNoValidate,
  NgControlStatus,
  NgControlStatusGroup,
  MaxLengthValidator,
  FormGroupDirective,
  FormControlName,
  IonButton,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonText
], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  color-scheme: light;\n}\n.category-manager[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 20px;\n}\n.category-form[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 14px;\n}\n.category-form[_ngcontent-%COMP%]   ion-item[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  --color: #172033;\n  --border-radius: 14px;\n  --padding-start: 14px;\n  --inner-padding-end: 14px;\n  border: 1px solid #e2e8f0;\n}\n.category-form[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%] {\n  --border-radius: 13px;\n  min-height: 50px;\n  text-transform: none;\n}\n.category-list[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 10px;\n  margin: 0;\n  padding: 0;\n  background: transparent;\n}\n.category-list[_ngcontent-%COMP%]   ion-item[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  --color: #172033;\n  --padding-start: 16px;\n  --inner-padding-end: 10px;\n  min-height: 62px;\n  border: 1px solid #e2e8f0;\n  border-radius: 14px;\n}\n.category-list[_ngcontent-%COMP%]   .empty-category[_ngcontent-%COMP%] {\n  --color: #667085;\n}\n.validation-message[_ngcontent-%COMP%] {\n  margin: -6px 8px 0;\n  font-size: 0.84rem;\n}\n.edit-form[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 8px 0;\n}\n.category-actions[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 8px;\n  margin-top: 8px;\n}\n/*# sourceMappingURL=category-manager.component.css.map */"], changeDetection: 0 });
var CategoryManagerComponent = _CategoryManagerComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CategoryManagerComponent, [{
    type: Component,
    args: [{ selector: "app-category-manager", standalone: true, imports: [
      ReactiveFormsModule,
      IonButton,
      IonInput,
      IonItem,
      IonLabel,
      IonList,
      IonText
    ], changeDetection: ChangeDetectionStrategy.OnPush, template: '<section class="category-manager">\n  <form\n    class="category-form"\n    [formGroup]="createForm"\n    (ngSubmit)="createCategory()"\n  >\n    <ion-item lines="none">\n      <ion-input\n        label="Nueva categoria"\n        labelPlacement="stacked"\n        placeholder="Ej. Trabajo"\n        maxlength="40"\n        formControlName="name"\n      />\n    </ion-item>\n\n    @if (\n      createForm.controls.name.touched\n      && createForm.controls.name.invalid\n    ) {\n      <ion-text color="danger">\n        <p class="validation-message">\n          Escribe un nombre de al menos 2 caracteres.\n        </p>\n      </ion-text>\n    }\n\n    <ion-button\n      expand="block"\n      type="submit"\n      [disabled]="createForm.invalid"\n    >\n      Crear categoria\n    </ion-button>\n  </form>\n\n  <ion-list class="category-list">\n    @for (\n      category of categories();\n      track category.id\n    ) {\n      <ion-item lines="none">\n        @if (editingCategoryId() === category.id) {\n          <form\n            class="edit-form"\n            [formGroup]="editForm"\n            (ngSubmit)="saveCategory(category.id)"\n          >\n            <ion-input\n              aria-label="Nombre de la categoria"\n              maxlength="40"\n              formControlName="name"\n            />\n\n            <div class="category-actions">\n              <ion-button\n                size="small"\n                type="submit"\n                [disabled]="editForm.invalid"\n              >\n                Guardar\n              </ion-button>\n\n              <ion-button\n                size="small"\n                fill="clear"\n                type="button"\n                (click)="cancelEditing()"\n              >\n                Cancelar\n              </ion-button>\n            </div>\n          </form>\n        } @else {\n          <ion-label>{{ category.name }}</ion-label>\n\n          <ion-button\n            slot="end"\n            size="small"\n            fill="clear"\n            (click)="startEditing(category)"\n          >\n            Editar\n          </ion-button>\n\n          <ion-button\n            slot="end"\n            size="small"\n            fill="clear"\n            color="danger"\n            (click)="categoryDeleted.emit(category.id)"\n          >\n            Eliminar\n          </ion-button>\n        }\n      </ion-item>\n    } @empty {\n      <ion-item\n        lines="none"\n        class="empty-category"\n      >\n        <ion-label>\n          No hay categorias creadas.\n        </ion-label>\n      </ion-item>\n    }\n  </ion-list>\n</section>\n', styles: ["/* src/app/features/categories/components/category-manager/category-manager.component.scss */\n:host {\n  display: block;\n  color-scheme: light;\n}\n.category-manager {\n  display: grid;\n  gap: 20px;\n}\n.category-form {\n  display: grid;\n  gap: 14px;\n}\n.category-form ion-item {\n  --background: #ffffff;\n  --color: #172033;\n  --border-radius: 14px;\n  --padding-start: 14px;\n  --inner-padding-end: 14px;\n  border: 1px solid #e2e8f0;\n}\n.category-form ion-button {\n  --border-radius: 13px;\n  min-height: 50px;\n  text-transform: none;\n}\n.category-list {\n  display: grid;\n  gap: 10px;\n  margin: 0;\n  padding: 0;\n  background: transparent;\n}\n.category-list ion-item {\n  --background: #ffffff;\n  --color: #172033;\n  --padding-start: 16px;\n  --inner-padding-end: 10px;\n  min-height: 62px;\n  border: 1px solid #e2e8f0;\n  border-radius: 14px;\n}\n.category-list .empty-category {\n  --color: #667085;\n}\n.validation-message {\n  margin: -6px 8px 0;\n  font-size: 0.84rem;\n}\n.edit-form {\n  width: 100%;\n  padding: 8px 0;\n}\n.category-actions {\n  display: flex;\n  gap: 8px;\n  margin-top: 8px;\n}\n/*# sourceMappingURL=category-manager.component.css.map */\n"] }]
  }], null, { categories: [{ type: Input, args: [{ isSignal: true, alias: "categories", required: false }] }], categoryCreated: [{ type: Output, args: ["categoryCreated"] }], categoryRenamed: [{ type: Output, args: ["categoryRenamed"] }], categoryDeleted: [{ type: Output, args: ["categoryDeleted"] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(CategoryManagerComponent, { className: "CategoryManagerComponent", filePath: "app/features/categories/components/category-manager/category-manager.component.ts", lineNumber: 48 });
})();

// src/app/features/categories/data-access/categories.facade.ts
var _CategoriesFacade = class _CategoriesFacade {
  constructor() {
    this.store = inject(TodoStore);
    this.loading = this.store.loading;
    this.categories = this.store.categories;
  }
  initialize() {
    return this.store.initialize();
  }
  addCategory(name) {
    return this.store.addCategory(name);
  }
  updateCategory(categoryId, name) {
    return this.store.updateCategory(categoryId, name);
  }
  deleteCategory(categoryId) {
    return this.store.deleteCategory(categoryId);
  }
};
_CategoriesFacade.\u0275fac = function CategoriesFacade_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _CategoriesFacade)();
};
_CategoriesFacade.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _CategoriesFacade, factory: _CategoriesFacade.\u0275fac, providedIn: "root" });
var CategoriesFacade = _CategoriesFacade;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CategoriesFacade, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

// src/app/features/categories/pages/category-list/category-list.page.ts
function CategoryListPage_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 4);
    \u0275\u0275element(1, "ion-spinner");
    \u0275\u0275elementEnd();
  }
}
function CategoryListPage_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "main", 5)(1, "section", 9)(2, "header")(3, "h1");
    \u0275\u0275text(4, "Categorias");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p");
    \u0275\u0275text(6, " Crea y administra las categorias de tus tareas. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "app-category-manager", 10);
    \u0275\u0275listener("categoryCreated", function CategoryListPage_Conditional_5_Template_app_category_manager_categoryCreated_7_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.createCategory($event));
    })("categoryRenamed", function CategoryListPage_Conditional_5_Template_app_category_manager_categoryRenamed_7_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.renameCategory($event));
    })("categoryDeleted", function CategoryListPage_Conditional_5_Template_app_category_manager_categoryDeleted_7_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.deleteCategory($event));
    });
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(7);
    \u0275\u0275property("categories", ctx_r1.facade.categories());
  }
}
var _CategoryListPage = class _CategoryListPage {
  constructor() {
    this.facade = inject(CategoriesFacade);
    this.toastOpen = signal(false, ...ngDevMode ? [{ debugName: "toastOpen" }] : []);
    this.toastMessage = signal("", ...ngDevMode ? [{ debugName: "toastMessage" }] : []);
  }
  ngOnInit() {
    return __async(this, null, function* () {
      yield this.facade.initialize();
    });
  }
  createCategory(name) {
    return __async(this, null, function* () {
      try {
        yield this.facade.addCategory(name);
      } catch (error) {
        this.showError(error);
      }
    });
  }
  renameCategory(input2) {
    return __async(this, null, function* () {
      try {
        yield this.facade.updateCategory(input2.id, input2.name);
      } catch (error) {
        this.showError(error);
      }
    });
  }
  deleteCategory(categoryId) {
    return __async(this, null, function* () {
      try {
        yield this.facade.deleteCategory(categoryId);
      } catch (error) {
        this.showError(error);
      }
    });
  }
  showError(error) {
    this.toastMessage.set(error instanceof Error ? error.message : "No fue posible completar la operacion.");
    this.toastOpen.set(true);
  }
};
_CategoryListPage.\u0275fac = function CategoryListPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _CategoryListPage)();
};
_CategoryListPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _CategoryListPage, selectors: [["app-category-list"]], decls: 10, vars: 4, consts: [[1, "page-header"], [1, "page-header-toolbar"], ["title", "Categorias"], [1, "page-content"], [1, "loading"], [1, "page-shell"], ["position", "bottom", 3, "didDismiss", "isOpen", "message", "duration"], [1, "page-footer"], [1, "page-footer-toolbar"], [1, "categories-view"], [3, "categoryCreated", "categoryRenamed", "categoryDeleted", "categories"]], template: function CategoryListPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1);
    \u0275\u0275element(2, "app-header", 2);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(3, "ion-content", 3);
    \u0275\u0275conditionalCreate(4, CategoryListPage_Conditional_4_Template, 2, 0, "div", 4)(5, CategoryListPage_Conditional_5_Template, 8, 1, "main", 5);
    \u0275\u0275elementStart(6, "ion-toast", 6);
    \u0275\u0275listener("didDismiss", function CategoryListPage_Template_ion_toast_didDismiss_6_listener() {
      return ctx.toastOpen.set(false);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "ion-footer", 7)(8, "ion-toolbar", 8);
    \u0275\u0275element(9, "app-bottom-navigation");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.facade.loading() ? 4 : 5);
    \u0275\u0275advance(2);
    \u0275\u0275property("isOpen", ctx.toastOpen())("message", ctx.toastMessage())("duration", 2600);
  }
}, dependencies: [
  IonContent,
  IonFooter,
  IonHeader,
  IonSpinner,
  IonToast,
  IonToolbar,
  AppHeaderComponent,
  BottomNavigationComponent,
  CategoryManagerComponent
], styles: ["\n\n[_nghost-%COMP%] {\n  --category-page-background: #f5f7fb;\n  --category-page-text: #172033;\n  --category-page-muted: #667085;\n}\n.page-header[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      var(--app-header-start),\n      var(--app-header-end));\n  box-shadow: 0 5px 18px rgba(20, 74, 150, 0.16);\n}\n.page-header-toolbar[_ngcontent-%COMP%] {\n  --background: transparent;\n  --border-width: 0;\n  --min-height: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n}\n.page-footer[_ngcontent-%COMP%] {\n  background: #ffffff;\n}\n.page-footer-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  --border-width: 0;\n  --min-height: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n  border-top: 1px solid #e2e8f0;\n  box-shadow: 0 -6px 20px rgba(31, 55, 90, 0.08);\n}\n.page-content[_ngcontent-%COMP%] {\n  --background: var(--category-page-background);\n  --color: var(--category-page-text);\n  --padding-top: 0;\n  --padding-bottom: 20px;\n}\n.page-shell[_ngcontent-%COMP%] {\n  width: min(100% - 24px, 760px);\n  margin: 0 auto;\n  padding: 24px 0 100px;\n}\n.categories-view[_ngcontent-%COMP%]   header[_ngcontent-%COMP%] {\n  margin-bottom: 24px;\n}\n.categories-view[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%], \n.categories-view[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n}\n.categories-view[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin-top: 7px;\n  color: var(--category-page-muted);\n}\n.loading[_ngcontent-%COMP%] {\n  display: grid;\n  min-height: 60vh;\n  place-items: center;\n}\n/*# sourceMappingURL=category-list.page.css.map */"], changeDetection: 0 });
var CategoryListPage = _CategoryListPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CategoryListPage, [{
    type: Component,
    args: [{ selector: "app-category-list", standalone: true, imports: [
      IonContent,
      IonFooter,
      IonHeader,
      IonSpinner,
      IonToast,
      IonToolbar,
      AppHeaderComponent,
      BottomNavigationComponent,
      CategoryManagerComponent
    ], changeDetection: ChangeDetectionStrategy.OnPush, template: '<ion-header class="page-header">\n  <ion-toolbar class="page-header-toolbar">\n    <app-header title="Categorias" />\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class="page-content">\n  @if (facade.loading()) {\n    <div class="loading">\n      <ion-spinner />\n    </div>\n  } @else {\n    <main class="page-shell">\n      <section class="categories-view">\n        <header>\n          <h1>Categorias</h1>\n          <p>\n            Crea y administra las categorias de tus tareas.\n          </p>\n        </header>\n\n        <app-category-manager\n          [categories]="facade.categories()"\n          (categoryCreated)="createCategory($event)"\n          (categoryRenamed)="renameCategory($event)"\n          (categoryDeleted)="deleteCategory($event)"\n        />\n      </section>\n    </main>\n  }\n\n  <ion-toast\n    [isOpen]="toastOpen()"\n    [message]="toastMessage()"\n    [duration]="2600"\n    position="bottom"\n    (didDismiss)="toastOpen.set(false)"\n  />\n</ion-content>\n\n<ion-footer class="page-footer">\n  <ion-toolbar class="page-footer-toolbar">\n    <app-bottom-navigation />\n  </ion-toolbar>\n</ion-footer>\n', styles: ["/* src/app/features/categories/pages/category-list/category-list.page.scss */\n:host {\n  --category-page-background: #f5f7fb;\n  --category-page-text: #172033;\n  --category-page-muted: #667085;\n}\n.page-header {\n  background:\n    linear-gradient(\n      135deg,\n      var(--app-header-start),\n      var(--app-header-end));\n  box-shadow: 0 5px 18px rgba(20, 74, 150, 0.16);\n}\n.page-header-toolbar {\n  --background: transparent;\n  --border-width: 0;\n  --min-height: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n}\n.page-footer {\n  background: #ffffff;\n}\n.page-footer-toolbar {\n  --background: #ffffff;\n  --border-width: 0;\n  --min-height: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n  border-top: 1px solid #e2e8f0;\n  box-shadow: 0 -6px 20px rgba(31, 55, 90, 0.08);\n}\n.page-content {\n  --background: var(--category-page-background);\n  --color: var(--category-page-text);\n  --padding-top: 0;\n  --padding-bottom: 20px;\n}\n.page-shell {\n  width: min(100% - 24px, 760px);\n  margin: 0 auto;\n  padding: 24px 0 100px;\n}\n.categories-view header {\n  margin-bottom: 24px;\n}\n.categories-view h1,\n.categories-view p {\n  margin: 0;\n}\n.categories-view p {\n  margin-top: 7px;\n  color: var(--category-page-muted);\n}\n.loading {\n  display: grid;\n  min-height: 60vh;\n  place-items: center;\n}\n/*# sourceMappingURL=category-list.page.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(CategoryListPage, { className: "CategoryListPage", filePath: "app/features/categories/pages/category-list/category-list.page.ts", lineNumber: 49 });
})();
export {
  CategoryListPage
};
//# sourceMappingURL=category-list.page-4IHIHLLZ.js.map
