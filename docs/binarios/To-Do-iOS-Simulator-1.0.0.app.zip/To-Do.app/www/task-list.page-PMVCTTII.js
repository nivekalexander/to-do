import {
  AppHeaderComponent,
  BottomNavigationComponent,
  TodoStore,
  add,
  addIcons,
  checkmark,
  checkmarkCircleOutline,
  clipboardOutline,
  closeOutline,
  ellipsisVertical,
  fileTrayOutline,
  optionsOutline,
  syncOutline,
  timeOutline,
  trashOutline
} from "./chunk-LAY7XXCO.js";
import {
  RemoteConfig,
  environment,
  fetchAndActivate,
  getBoolean,
  isSupported
} from "./chunk-FXRVKLVH.js";
import {
  ChangeDetectionStrategy,
  Component,
  FormBuilder,
  FormControlName,
  FormGroupDirective,
  Injectable,
  Input,
  IonAccordion,
  IonAccordionGroup,
  IonButton,
  IonContent,
  IonFab,
  IonFabButton,
  IonFooter,
  IonHeader,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonModal,
  IonSelect,
  IonSelectOption,
  IonSpinner,
  IonText,
  IonToast,
  IonToolbar,
  MaxLengthValidator,
  NgControlStatus,
  NgControlStatusGroup,
  Output,
  ReactiveFormsModule,
  Validators,
  computed,
  inject,
  input,
  output,
  setClassMetadata,
  signal,
  ɵNgNoValidate,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵprojection,
  ɵɵprojectionDef,
  ɵɵproperty,
  ɵɵreference,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-DSNEALCX.js";
import "./chunk-23OV75OR.js";
import "./chunk-ZANXXOCD.js";
import "./chunk-SA4GQGRP.js";
import "./chunk-V55YLP36.js";
import "./chunk-B3Y7DSCZ.js";
import "./chunk-I5FGWB6R.js";
import "./chunk-6GY55RSK.js";
import "./chunk-7D2IXJO2.js";
import "./chunk-FZZSIR43.js";
import "./chunk-X4NBNE3H.js";
import "./chunk-PBXPKCK6.js";
import "./chunk-2SCNBYQ2.js";
import "./chunk-YAS4LRVC.js";
import {
  __async,
  __spreadValues
} from "./chunk-NB53XM2W.js";

// src/app/shared/components/app-modal/app-modal.component.ts
var _c0 = ["*"];
function AppModalComponent_ng_template_2_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r2.description());
  }
}
function AppModalComponent_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 2)(1, "header", 3)(2, "div")(3, "h2");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(5, AppModalComponent_ng_template_2_Conditional_5_Template, 2, 1, "p");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "button", 4);
    \u0275\u0275listener("click", function AppModalComponent_ng_template_2_Template_button_click_6_listener() {
      \u0275\u0275restoreView(_r2);
      \u0275\u0275nextContext();
      const modal_r4 = \u0275\u0275reference(1);
      return \u0275\u0275resetView(modal_r4.dismiss());
    });
    \u0275\u0275element(7, "ion-icon", 5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 6);
    \u0275\u0275projection(9);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275attribute("aria-label", ctx_r2.title());
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r2.title());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.description() ? 5 : -1);
  }
}
var _AppModalComponent = class _AppModalComponent {
  constructor() {
    this.open = input(false, ...ngDevMode ? [{ debugName: "open" }] : []);
    this.title = input.required(...ngDevMode ? [{ debugName: "title" }] : []);
    this.description = input("", ...ngDevMode ? [{ debugName: "description" }] : []);
    this.backdropDismiss = input(true, ...ngDevMode ? [{ debugName: "backdropDismiss" }] : []);
    this.closed = output();
    addIcons({ closeOutline });
  }
};
_AppModalComponent.\u0275fac = function AppModalComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AppModalComponent)();
};
_AppModalComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AppModalComponent, selectors: [["app-modal"]], inputs: { open: [1, "open"], title: [1, "title"], description: [1, "description"], backdropDismiss: [1, "backdropDismiss"] }, outputs: { closed: "closed" }, ngContentSelectors: _c0, decls: 3, vars: 3, consts: [["modal", ""], [1, "app-centered-modal", 3, "didDismiss", "isOpen", "backdropDismiss", "keyboardClose"], ["role", "dialog", "aria-modal", "true", 1, "app-modal-dialog"], [1, "app-modal-header"], ["type", "button", "aria-label", "Cerrar", 1, "app-modal-close", 3, "click"], ["name", "close-outline"], [1, "app-modal-body"]], template: function AppModalComponent_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275projectionDef();
    \u0275\u0275elementStart(0, "ion-modal", 1, 0);
    \u0275\u0275listener("didDismiss", function AppModalComponent_Template_ion_modal_didDismiss_0_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.closed.emit());
    });
    \u0275\u0275template(2, AppModalComponent_ng_template_2_Template, 10, 3, "ng-template");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275property("isOpen", ctx.open())("backdropDismiss", ctx.backdropDismiss())("keyboardClose", true);
  }
}, dependencies: [
  IonIcon,
  IonModal
], styles: ["\n\n.app-modal-dialog[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-rows: auto minmax(0, 1fr);\n  max-height: min(82vh, 700px);\n  overflow: hidden;\n  border-radius: 22px;\n  background: #ffffff;\n  color: #172033;\n}\n.app-modal-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  justify-content: space-between;\n  gap: 18px;\n  padding: 22px 22px 16px;\n  border-bottom: 1px solid #e2e8f0;\n}\n.app-modal-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%], \n.app-modal-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n}\n.app-modal-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 1.35rem;\n  font-weight: 700;\n}\n.app-modal-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin-top: 6px;\n  color: #667085;\n  line-height: 1.4;\n}\n.app-modal-close[_ngcontent-%COMP%] {\n  display: grid;\n  flex: 0 0 40px;\n  width: 40px;\n  height: 40px;\n  place-items: center;\n  border: 0;\n  border-radius: 999px;\n  background: #f2f4f7;\n  color: #475467;\n  cursor: pointer;\n}\n.app-modal-close[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n}\n.app-modal-body[_ngcontent-%COMP%] {\n  min-height: 0;\n  overflow-y: auto;\n  overscroll-behavior: contain;\n  padding: 20px 22px 24px;\n}\n@media (max-width: 480px) {\n  .app-modal-dialog[_ngcontent-%COMP%] {\n    max-height: calc(100dvh - 28px);\n  }\n  .app-modal-header[_ngcontent-%COMP%] {\n    padding: 20px 18px 15px;\n  }\n  .app-modal-body[_ngcontent-%COMP%] {\n    padding: 18px 18px 22px;\n  }\n}\n/*# sourceMappingURL=app-modal.component.css.map */"], changeDetection: 0 });
var AppModalComponent = _AppModalComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AppModalComponent, [{
    type: Component,
    args: [{ selector: "app-modal", standalone: true, imports: [
      IonIcon,
      IonModal
    ], changeDetection: ChangeDetectionStrategy.OnPush, template: '<ion-modal\n  #modal\n  class="app-centered-modal"\n  [isOpen]="open()"\n  [backdropDismiss]="backdropDismiss()"\n  [keyboardClose]="true"\n  (didDismiss)="closed.emit()"\n>\n  <ng-template>\n    <section\n      class="app-modal-dialog"\n      role="dialog"\n      aria-modal="true"\n      [attr.aria-label]="title()"\n    >\n      <header class="app-modal-header">\n        <div>\n          <h2>{{ title() }}</h2>\n\n          @if (description()) {\n            <p>{{ description() }}</p>\n          }\n        </div>\n\n        <button\n          type="button"\n          class="app-modal-close"\n          aria-label="Cerrar"\n          (click)="modal.dismiss()"\n        >\n          <ion-icon name="close-outline" />\n        </button>\n      </header>\n\n      <div class="app-modal-body">\n        <ng-content></ng-content>\n      </div>\n    </section>\n  </ng-template>\n</ion-modal>\n', styles: ["/* src/app/shared/components/app-modal/app-modal.component.scss */\n.app-modal-dialog {\n  display: grid;\n  grid-template-rows: auto minmax(0, 1fr);\n  max-height: min(82vh, 700px);\n  overflow: hidden;\n  border-radius: 22px;\n  background: #ffffff;\n  color: #172033;\n}\n.app-modal-header {\n  display: flex;\n  align-items: flex-start;\n  justify-content: space-between;\n  gap: 18px;\n  padding: 22px 22px 16px;\n  border-bottom: 1px solid #e2e8f0;\n}\n.app-modal-header h2,\n.app-modal-header p {\n  margin: 0;\n}\n.app-modal-header h2 {\n  font-size: 1.35rem;\n  font-weight: 700;\n}\n.app-modal-header p {\n  margin-top: 6px;\n  color: #667085;\n  line-height: 1.4;\n}\n.app-modal-close {\n  display: grid;\n  flex: 0 0 40px;\n  width: 40px;\n  height: 40px;\n  place-items: center;\n  border: 0;\n  border-radius: 999px;\n  background: #f2f4f7;\n  color: #475467;\n  cursor: pointer;\n}\n.app-modal-close ion-icon {\n  font-size: 24px;\n}\n.app-modal-body {\n  min-height: 0;\n  overflow-y: auto;\n  overscroll-behavior: contain;\n  padding: 20px 22px 24px;\n}\n@media (max-width: 480px) {\n  .app-modal-dialog {\n    max-height: calc(100dvh - 28px);\n  }\n  .app-modal-header {\n    padding: 20px 18px 15px;\n  }\n  .app-modal-body {\n    padding: 18px 18px 22px;\n  }\n}\n/*# sourceMappingURL=app-modal.component.css.map */\n"] }]
  }], () => [], { open: [{ type: Input, args: [{ isSignal: true, alias: "open", required: false }] }], title: [{ type: Input, args: [{ isSignal: true, alias: "title", required: true }] }], description: [{ type: Input, args: [{ isSignal: true, alias: "description", required: false }] }], backdropDismiss: [{ type: Input, args: [{ isSignal: true, alias: "backdropDismiss", required: false }] }], closed: [{ type: Output, args: ["closed"] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AppModalComponent, { className: "AppModalComponent", filePath: "app/shared/components/app-modal/app-modal.component.ts", lineNumber: 25 });
})();

// src/app/shared/components/empty-state/empty-state.component.ts
function EmptyStateComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.message());
  }
}
var _EmptyStateComponent = class _EmptyStateComponent {
  constructor() {
    this.title = input.required(...ngDevMode ? [{ debugName: "title" }] : []);
    this.message = input("", ...ngDevMode ? [{ debugName: "message" }] : []);
    this.compact = input(false, ...ngDevMode ? [{ debugName: "compact" }] : []);
    addIcons({ fileTrayOutline });
  }
};
_EmptyStateComponent.\u0275fac = function EmptyStateComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _EmptyStateComponent)();
};
_EmptyStateComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _EmptyStateComponent, selectors: [["app-empty-state"]], inputs: { title: [1, "title"], message: [1, "message"], compact: [1, "compact"] }, decls: 5, vars: 4, consts: [[1, "empty-state"], ["name", "file-tray-outline"]], template: function EmptyStateComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 0);
    \u0275\u0275element(1, "ion-icon", 1);
    \u0275\u0275elementStart(2, "strong");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(4, EmptyStateComponent_Conditional_4_Template, 2, 1, "p");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275classProp("compact", ctx.compact());
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx.title());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.message() ? 4 : -1);
  }
}, dependencies: [IonIcon], styles: ["\n\n.empty-state[_ngcontent-%COMP%] {\n  display: grid;\n  justify-items: center;\n  gap: 8px;\n  padding: 36px 20px;\n  text-align: center;\n  color: var(--app-text-muted);\n}\n.empty-state.compact[_ngcontent-%COMP%] {\n  padding: 24px 16px;\n}\nion-icon[_ngcontent-%COMP%] {\n  font-size: 34px;\n}\nstrong[_ngcontent-%COMP%] {\n  color: var(--app-text);\n}\np[_ngcontent-%COMP%] {\n  margin: 0;\n  line-height: 1.45;\n}\n/*# sourceMappingURL=empty-state.component.css.map */"], changeDetection: 0 });
var EmptyStateComponent = _EmptyStateComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(EmptyStateComponent, [{
    type: Component,
    args: [{ selector: "app-empty-state", standalone: true, imports: [IonIcon], changeDetection: ChangeDetectionStrategy.OnPush, template: '<section\n  class="empty-state"\n  [class.compact]="compact()"\n>\n  <ion-icon name="file-tray-outline" />\n\n  <strong>{{ title() }}</strong>\n\n  @if (message()) {\n    <p>{{ message() }}</p>\n  }\n</section>\n', styles: ["/* src/app/shared/components/empty-state/empty-state.component.scss */\n.empty-state {\n  display: grid;\n  justify-items: center;\n  gap: 8px;\n  padding: 36px 20px;\n  text-align: center;\n  color: var(--app-text-muted);\n}\n.empty-state.compact {\n  padding: 24px 16px;\n}\nion-icon {\n  font-size: 34px;\n}\nstrong {\n  color: var(--app-text);\n}\np {\n  margin: 0;\n  line-height: 1.45;\n}\n/*# sourceMappingURL=empty-state.component.css.map */\n"] }]
  }], () => [], { title: [{ type: Input, args: [{ isSignal: true, alias: "title", required: true }] }], message: [{ type: Input, args: [{ isSignal: true, alias: "message", required: false }] }], compact: [{ type: Input, args: [{ isSignal: true, alias: "compact", required: false }] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(EmptyStateComponent, { className: "EmptyStateComponent", filePath: "app/shared/components/empty-state/empty-state.component.ts", lineNumber: 18 });
})();

// src/app/features/tasks/components/task-actions/task-actions.component.ts
function TaskActionsComponent_Conditional_1_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 9);
    \u0275\u0275listener("click", function TaskActionsComponent_Conditional_1_Conditional_1_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.moved.emit("not-started"));
    });
    \u0275\u0275elementStart(1, "span", 6);
    \u0275\u0275element(2, "ion-icon", 10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 8)(4, "strong");
    \u0275\u0275text(5, "Mover a No iniciado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "small");
    \u0275\u0275text(7, "La tarea vuelve al estado inicial.");
    \u0275\u0275elementEnd()()();
  }
}
function TaskActionsComponent_Conditional_1_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 11);
    \u0275\u0275listener("click", function TaskActionsComponent_Conditional_1_Conditional_2_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.moved.emit("in-progress"));
    });
    \u0275\u0275elementStart(1, "span", 6);
    \u0275\u0275element(2, "ion-icon", 12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 8)(4, "strong");
    \u0275\u0275text(5, "Mover a En progreso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "small");
    \u0275\u0275text(7, "Marca la tarea como trabajo activo.");
    \u0275\u0275elementEnd()()();
  }
}
function TaskActionsComponent_Conditional_1_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 13);
    \u0275\u0275listener("click", function TaskActionsComponent_Conditional_1_Conditional_3_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.moved.emit("finished"));
    });
    \u0275\u0275elementStart(1, "span", 6);
    \u0275\u0275element(2, "ion-icon", 14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 8)(4, "strong");
    \u0275\u0275text(5, "Mover a Terminado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "small");
    \u0275\u0275text(7, "Registra la tarea como completada.");
    \u0275\u0275elementEnd()()();
  }
}
function TaskActionsComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 1);
    \u0275\u0275conditionalCreate(1, TaskActionsComponent_Conditional_1_Conditional_1_Template, 8, 0, "button", 2);
    \u0275\u0275conditionalCreate(2, TaskActionsComponent_Conditional_1_Conditional_2_Template, 8, 0, "button", 3);
    \u0275\u0275conditionalCreate(3, TaskActionsComponent_Conditional_1_Conditional_3_Template, 8, 0, "button", 4);
    \u0275\u0275elementStart(4, "button", 5);
    \u0275\u0275listener("click", function TaskActionsComponent_Conditional_1_Template_button_click_4_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.deleted.emit());
    });
    \u0275\u0275elementStart(5, "span", 6);
    \u0275\u0275element(6, "ion-icon", 7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span", 8)(8, "strong");
    \u0275\u0275text(9, "Eliminar tarea");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "small");
    \u0275\u0275text(11, "Esta accion no se puede deshacer.");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const selectedTask_r6 = ctx;
    \u0275\u0275advance();
    \u0275\u0275conditional(selectedTask_r6.status !== "not-started" ? 1 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(selectedTask_r6.status !== "in-progress" ? 2 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(selectedTask_r6.status !== "finished" ? 3 : -1);
  }
}
var _TaskActionsComponent = class _TaskActionsComponent {
  constructor() {
    this.task = input(null, ...ngDevMode ? [{ debugName: "task" }] : []);
    this.open = input(false, ...ngDevMode ? [{ debugName: "open" }] : []);
    this.moved = output();
    this.deleted = output();
    this.closed = output();
    addIcons({
      checkmarkCircleOutline,
      syncOutline,
      timeOutline,
      trashOutline
    });
  }
};
_TaskActionsComponent.\u0275fac = function TaskActionsComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _TaskActionsComponent)();
};
_TaskActionsComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _TaskActionsComponent, selectors: [["app-task-actions"]], inputs: { task: [1, "task"], open: [1, "open"] }, outputs: { moved: "moved", deleted: "deleted", closed: "closed" }, decls: 2, vars: 3, consts: [["title", "Acciones de tarea", 3, "closed", "open", "description"], [1, "task-actions"], ["type", "button", 1, "task-action", "not-started"], ["type", "button", 1, "task-action", "in-progress"], ["type", "button", 1, "task-action", "finished"], ["type", "button", 1, "task-action", "delete", 3, "click"], [1, "action-icon"], ["name", "trash-outline"], [1, "action-copy"], ["type", "button", 1, "task-action", "not-started", 3, "click"], ["name", "time-outline"], ["type", "button", 1, "task-action", "in-progress", 3, "click"], ["name", "sync-outline"], ["type", "button", 1, "task-action", "finished", 3, "click"], ["name", "checkmark-circle-outline"]], template: function TaskActionsComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "app-modal", 0);
    \u0275\u0275listener("closed", function TaskActionsComponent_Template_app_modal_closed_0_listener() {
      return ctx.closed.emit();
    });
    \u0275\u0275conditionalCreate(1, TaskActionsComponent_Conditional_1_Template, 12, 3, "section", 1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_1_0;
    let tmp_2_0;
    \u0275\u0275property("open", ctx.open())("description", ((tmp_1_0 = ctx.task()) == null ? null : tmp_1_0.title) ?? "");
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_2_0 = ctx.task()) ? 1 : -1, tmp_2_0);
  }
}, dependencies: [
  IonIcon,
  AppModalComponent
], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n}\n.task-actions[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 10px;\n}\n.task-action[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 46px minmax(0, 1fr);\n  align-items: center;\n  gap: 14px;\n  width: 100%;\n  min-height: 72px;\n  padding: 12px 14px;\n  border: 1px solid #e2e8f0;\n  border-radius: 14px;\n  background: #ffffff;\n  color: #172033;\n  font: inherit;\n  text-align: left;\n  cursor: pointer;\n  transition:\n    background-color 160ms ease,\n    border-color 160ms ease,\n    transform 160ms ease;\n}\n.task-action[_ngcontent-%COMP%]:hover {\n  border-color: #cbd5e1;\n  background: #f8fafc;\n}\n.task-action[_ngcontent-%COMP%]:active {\n  transform: scale(0.99);\n}\n.action-icon[_ngcontent-%COMP%] {\n  display: grid;\n  width: 42px;\n  height: 42px;\n  place-items: center;\n  border-radius: 12px;\n  background: #f2f4f7;\n}\n.action-icon[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 25px;\n}\n.action-copy[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 4px;\n  min-width: 0;\n}\n.action-copy[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  font-size: 0.98rem;\n  font-weight: 650;\n}\n.action-copy[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  overflow: hidden;\n  color: #667085;\n  font-size: 0.8rem;\n  line-height: 1.35;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.not-started[_ngcontent-%COMP%]   .action-icon[_ngcontent-%COMP%] {\n  background: #fff3e8;\n  color: #ef6c00;\n}\n.in-progress[_ngcontent-%COMP%]   .action-icon[_ngcontent-%COMP%] {\n  background: #eaf2ff;\n  color: #1769e8;\n}\n.finished[_ngcontent-%COMP%]   .action-icon[_ngcontent-%COMP%] {\n  background: #e9f8f1;\n  color: #0f9f63;\n}\n.delete[_ngcontent-%COMP%] {\n  border-color: #fecaca;\n}\n.delete[_ngcontent-%COMP%]   .action-icon[_ngcontent-%COMP%] {\n  background: #fff1f2;\n  color: #dc2626;\n}\n.delete[_ngcontent-%COMP%]   .action-copy[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #dc2626;\n}\n@media (max-width: 420px) {\n  .task-action[_ngcontent-%COMP%] {\n    grid-template-columns: 42px minmax(0, 1fr);\n    min-height: 68px;\n    padding: 10px 12px;\n  }\n  .action-icon[_ngcontent-%COMP%] {\n    width: 38px;\n    height: 38px;\n  }\n}\n/*# sourceMappingURL=task-actions.component.css.map */"], changeDetection: 0 });
var TaskActionsComponent = _TaskActionsComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TaskActionsComponent, [{
    type: Component,
    args: [{ selector: "app-task-actions", standalone: true, imports: [
      IonIcon,
      AppModalComponent
    ], changeDetection: ChangeDetectionStrategy.OnPush, template: `<app-modal
  [open]="open()"
  title="Acciones de tarea"
  [description]="task()?.title ?? ''"
  (closed)="closed.emit()"
>
  @if (task(); as selectedTask) {
    <section class="task-actions">
      @if (selectedTask.status !== 'not-started') {
        <button
          type="button"
          class="task-action not-started"
          (click)="moved.emit('not-started')"
        >
          <span class="action-icon">
            <ion-icon name="time-outline" />
          </span>

          <span class="action-copy">
            <strong>Mover a No iniciado</strong>
            <small>La tarea vuelve al estado inicial.</small>
          </span>
        </button>
      }

      @if (selectedTask.status !== 'in-progress') {
        <button
          type="button"
          class="task-action in-progress"
          (click)="moved.emit('in-progress')"
        >
          <span class="action-icon">
            <ion-icon name="sync-outline" />
          </span>

          <span class="action-copy">
            <strong>Mover a En progreso</strong>
            <small>Marca la tarea como trabajo activo.</small>
          </span>
        </button>
      }

      @if (selectedTask.status !== 'finished') {
        <button
          type="button"
          class="task-action finished"
          (click)="moved.emit('finished')"
        >
          <span class="action-icon">
            <ion-icon name="checkmark-circle-outline" />
          </span>

          <span class="action-copy">
            <strong>Mover a Terminado</strong>
            <small>Registra la tarea como completada.</small>
          </span>
        </button>
      }

      <button
        type="button"
        class="task-action delete"
        (click)="deleted.emit()"
      >
        <span class="action-icon">
          <ion-icon name="trash-outline" />
        </span>

        <span class="action-copy">
          <strong>Eliminar tarea</strong>
          <small>Esta accion no se puede deshacer.</small>
        </span>
      </button>
    </section>
  }
</app-modal>
`, styles: ["/* src/app/features/tasks/components/task-actions/task-actions.component.scss */\n:host {\n  display: block;\n}\n.task-actions {\n  display: grid;\n  gap: 10px;\n}\n.task-action {\n  display: grid;\n  grid-template-columns: 46px minmax(0, 1fr);\n  align-items: center;\n  gap: 14px;\n  width: 100%;\n  min-height: 72px;\n  padding: 12px 14px;\n  border: 1px solid #e2e8f0;\n  border-radius: 14px;\n  background: #ffffff;\n  color: #172033;\n  font: inherit;\n  text-align: left;\n  cursor: pointer;\n  transition:\n    background-color 160ms ease,\n    border-color 160ms ease,\n    transform 160ms ease;\n}\n.task-action:hover {\n  border-color: #cbd5e1;\n  background: #f8fafc;\n}\n.task-action:active {\n  transform: scale(0.99);\n}\n.action-icon {\n  display: grid;\n  width: 42px;\n  height: 42px;\n  place-items: center;\n  border-radius: 12px;\n  background: #f2f4f7;\n}\n.action-icon ion-icon {\n  font-size: 25px;\n}\n.action-copy {\n  display: grid;\n  gap: 4px;\n  min-width: 0;\n}\n.action-copy strong {\n  font-size: 0.98rem;\n  font-weight: 650;\n}\n.action-copy small {\n  overflow: hidden;\n  color: #667085;\n  font-size: 0.8rem;\n  line-height: 1.35;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.not-started .action-icon {\n  background: #fff3e8;\n  color: #ef6c00;\n}\n.in-progress .action-icon {\n  background: #eaf2ff;\n  color: #1769e8;\n}\n.finished .action-icon {\n  background: #e9f8f1;\n  color: #0f9f63;\n}\n.delete {\n  border-color: #fecaca;\n}\n.delete .action-icon {\n  background: #fff1f2;\n  color: #dc2626;\n}\n.delete .action-copy strong {\n  color: #dc2626;\n}\n@media (max-width: 420px) {\n  .task-action {\n    grid-template-columns: 42px minmax(0, 1fr);\n    min-height: 68px;\n    padding: 10px 12px;\n  }\n  .action-icon {\n    width: 38px;\n    height: 38px;\n  }\n}\n/*# sourceMappingURL=task-actions.component.css.map */\n"] }]
  }], () => [], { task: [{ type: Input, args: [{ isSignal: true, alias: "task", required: false }] }], open: [{ type: Input, args: [{ isSignal: true, alias: "open", required: false }] }], moved: [{ type: Output, args: ["moved"] }], deleted: [{ type: Output, args: ["deleted"] }], closed: [{ type: Output, args: ["closed"] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(TaskActionsComponent, { className: "TaskActionsComponent", filePath: "app/features/tasks/components/task-actions/task-actions.component.ts", lineNumber: 37 });
})();

// src/app/features/tasks/components/task-filter/task-filter.component.ts
var _forTrack0 = ($index, $item) => $item.value;
var _forTrack1 = ($index, $item) => $item.id;
function TaskFilterComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 2);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r0.activeCount(), " ");
  }
}
function TaskFilterComponent_For_16_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 11);
  }
}
function TaskFilterComponent_For_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 14);
    \u0275\u0275listener("click", function TaskFilterComponent_For_16_Template_button_click_0_listener() {
      const option_r3 = \u0275\u0275restoreView(_r2).$implicit;
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.selectStatus(option_r3.value));
    });
    \u0275\u0275text(1);
    \u0275\u0275conditionalCreate(2, TaskFilterComponent_For_16_Conditional_2_Template, 1, 0, "ion-icon", 11);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const option_r3 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275classProp("selected", ctx_r0.selectedStatus() === option_r3.value);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", option_r3.label, " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.selectedStatus() === option_r3.value ? 2 : -1);
  }
}
function TaskFilterComponent_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 11);
  }
}
function TaskFilterComponent_For_24_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 11);
  }
}
function TaskFilterComponent_For_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 10);
    \u0275\u0275listener("click", function TaskFilterComponent_For_24_Template_button_click_0_listener() {
      const category_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.selectCategory(category_r5.id));
    });
    \u0275\u0275text(1);
    \u0275\u0275conditionalCreate(2, TaskFilterComponent_For_24_Conditional_2_Template, 1, 0, "ion-icon", 11);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const category_r5 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275classProp("selected", ctx_r0.selectedCategoryId() === category_r5.id);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", category_r5.name, " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.selectedCategoryId() === category_r5.id ? 2 : -1);
  }
}
var _TaskFilterComponent = class _TaskFilterComponent {
  constructor() {
    this.categories = input([], ...ngDevMode ? [{ debugName: "categories" }] : []);
    this.filters = input.required(...ngDevMode ? [{ debugName: "filters" }] : []);
    this.filterChanged = output();
    this.filtersCleared = output();
    this.open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : []);
    this.selectedCategoryId = signal(null, ...ngDevMode ? [{ debugName: "selectedCategoryId" }] : []);
    this.selectedStatus = signal("all", ...ngDevMode ? [{ debugName: "selectedStatus" }] : []);
    this.statusOptions = [
      { value: "all", label: "Todos" },
      { value: "not-started", label: "No iniciado" },
      { value: "in-progress", label: "En progreso" },
      { value: "finished", label: "Terminado" }
    ];
    this.activeCount = computed(() => {
      const filters = this.filters();
      return Number(filters.categoryId !== null) + Number(filters.status !== null);
    }, ...ngDevMode ? [{ debugName: "activeCount" }] : []);
    addIcons({
      checkmark,
      optionsOutline
    });
  }
  openFilters() {
    const filters = this.filters();
    this.selectedCategoryId.set(filters.categoryId);
    this.selectedStatus.set(filters.status ?? "all");
    this.open.set(true);
  }
  closeFilters() {
    this.open.set(false);
  }
  selectCategory(categoryId) {
    this.selectedCategoryId.set(categoryId);
  }
  selectStatus(status) {
    this.selectedStatus.set(status);
  }
  applyFilters() {
    this.filterChanged.emit({
      categoryId: this.selectedCategoryId(),
      status: this.selectedStatus() === "all" ? null : this.selectedStatus()
    });
    this.closeFilters();
  }
  clearFilters() {
    this.selectedCategoryId.set(null);
    this.selectedStatus.set("all");
    this.filtersCleared.emit();
    this.closeFilters();
  }
};
_TaskFilterComponent.\u0275fac = function TaskFilterComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _TaskFilterComponent)();
};
_TaskFilterComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _TaskFilterComponent, selectors: [["app-task-filter"]], inputs: { categories: [1, "categories"], filters: [1, "filters"] }, outputs: { filterChanged: "filterChanged", filtersCleared: "filtersCleared" }, decls: 27, vars: 6, consts: [["expand", "block", "fill", "outline", 1, "filter-button", 3, "click"], ["slot", "start", "name", "options-outline"], [1, "filter-count"], ["title", "Filtros", "description", "Combina un estado y una categoria.", 3, "closed", "open"], [1, "filter-content"], [1, "filter-toolbar"], ["type", "button", 1, "clear-button", 3, "click"], [1, "filter-section"], [1, "option-grid"], ["type", "button", 1, "option-button", 3, "selected"], ["type", "button", 1, "category-option", 3, "click"], ["name", "checkmark"], ["type", "button", 1, "category-option", 3, "selected"], ["expand", "block", 3, "click"], ["type", "button", 1, "option-button", 3, "click"]], template: function TaskFilterComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-button", 0);
    \u0275\u0275listener("click", function TaskFilterComponent_Template_ion_button_click_0_listener() {
      return ctx.openFilters();
    });
    \u0275\u0275element(1, "ion-icon", 1);
    \u0275\u0275text(2, " Filtros ");
    \u0275\u0275conditionalCreate(3, TaskFilterComponent_Conditional_3_Template, 2, 1, "span", 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "app-modal", 3);
    \u0275\u0275listener("closed", function TaskFilterComponent_Template_app_modal_closed_4_listener() {
      return ctx.closeFilters();
    });
    \u0275\u0275elementStart(5, "section", 4)(6, "div", 5)(7, "span");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "button", 6);
    \u0275\u0275listener("click", function TaskFilterComponent_Template_button_click_9_listener() {
      return ctx.clearFilters();
    });
    \u0275\u0275text(10, " Limpiar ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 7)(12, "h3");
    \u0275\u0275text(13, "Estado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "div", 8);
    \u0275\u0275repeaterCreate(15, TaskFilterComponent_For_16_Template, 3, 4, "button", 9, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(17, "div", 7)(18, "h3");
    \u0275\u0275text(19, "Categoria");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "button", 10);
    \u0275\u0275listener("click", function TaskFilterComponent_Template_button_click_20_listener() {
      return ctx.selectCategory(null);
    });
    \u0275\u0275text(21, " Todas las categorias ");
    \u0275\u0275conditionalCreate(22, TaskFilterComponent_Conditional_22_Template, 1, 0, "ion-icon", 11);
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(23, TaskFilterComponent_For_24_Template, 3, 4, "button", 12, _forTrack1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "ion-button", 13);
    \u0275\u0275listener("click", function TaskFilterComponent_Template_ion_button_click_25_listener() {
      return ctx.applyFilters();
    });
    \u0275\u0275text(26, " Aplicar filtros ");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.activeCount() > 0 ? 3 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("open", ctx.open());
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", ctx.activeCount(), " filtro(s) activo(s) ");
    \u0275\u0275advance(7);
    \u0275\u0275repeater(ctx.statusOptions);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("selected", ctx.selectedCategoryId() === null);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.selectedCategoryId() === null ? 22 : -1);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx.categories());
  }
}, dependencies: [
  IonButton,
  IonIcon,
  AppModalComponent
], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  color-scheme: light;\n}\n.filter-button[_ngcontent-%COMP%] {\n  --border-radius: 14px;\n  --border-width: 1.5px;\n  --border-color: #1769e8;\n  --color: #1769e8;\n  --background: #ffffff;\n  --background-hover: #f4f8ff;\n  min-height: 56px;\n  margin: 0;\n  font-weight: 600;\n  text-transform: none;\n}\n.filter-count[_ngcontent-%COMP%] {\n  display: inline-grid;\n  min-width: 24px;\n  min-height: 24px;\n  margin-left: 8px;\n  place-items: center;\n  border-radius: 999px;\n  background: #1769e8;\n  color: #ffffff;\n  font-size: 0.8rem;\n}\n.filter-content[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 24px;\n}\n.filter-toolbar[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n  color: #667085;\n  font-size: 0.9rem;\n}\n.clear-button[_ngcontent-%COMP%] {\n  border: 0;\n  background: transparent;\n  color: #1769e8;\n  font: inherit;\n  font-weight: 600;\n  cursor: pointer;\n}\n.filter-section[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 12px;\n}\n.filter-section[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0;\n  color: #172033;\n  font-size: 1rem;\n}\n.option-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 10px;\n}\n.option-button[_ngcontent-%COMP%], \n.category-option[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 10px;\n  min-height: 50px;\n  padding: 0 14px;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  background: #ffffff;\n  color: #172033;\n  font: inherit;\n  text-align: left;\n  cursor: pointer;\n}\n.option-button.selected[_ngcontent-%COMP%], \n.category-option.selected[_ngcontent-%COMP%] {\n  border-color: #1769e8;\n  background: #eef5ff;\n  color: #1769e8;\n}\n.filter-content[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%] {\n  --border-radius: 13px;\n  min-height: 50px;\n  margin: 0;\n  text-transform: none;\n}\n/*# sourceMappingURL=task-filter.component.css.map */"], changeDetection: 0 });
var TaskFilterComponent = _TaskFilterComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TaskFilterComponent, [{
    type: Component,
    args: [{ selector: "app-task-filter", standalone: true, imports: [
      IonButton,
      IonIcon,
      AppModalComponent
    ], changeDetection: ChangeDetectionStrategy.OnPush, template: '<ion-button\n  class="filter-button"\n  expand="block"\n  fill="outline"\n  (click)="openFilters()"\n>\n  <ion-icon\n    slot="start"\n    name="options-outline"\n  />\n\n  Filtros\n\n  @if (activeCount() > 0) {\n    <span class="filter-count">\n      {{ activeCount() }}\n    </span>\n  }\n</ion-button>\n\n<app-modal\n  [open]="open()"\n  title="Filtros"\n  description="Combina un estado y una categoria."\n  (closed)="closeFilters()"\n>\n  <section class="filter-content">\n    <div class="filter-toolbar">\n      <span>\n        {{ activeCount() }} filtro(s) activo(s)\n      </span>\n\n      <button\n        type="button"\n        class="clear-button"\n        (click)="clearFilters()"\n      >\n        Limpiar\n      </button>\n    </div>\n\n    <div class="filter-section">\n      <h3>Estado</h3>\n\n      <div class="option-grid">\n        @for (\n          option of statusOptions;\n          track option.value\n        ) {\n          <button\n            type="button"\n            class="option-button"\n            [class.selected]="selectedStatus() === option.value"\n            (click)="selectStatus(option.value)"\n          >\n            {{ option.label }}\n\n            @if (selectedStatus() === option.value) {\n              <ion-icon name="checkmark" />\n            }\n          </button>\n        }\n      </div>\n    </div>\n\n    <div class="filter-section">\n      <h3>Categoria</h3>\n\n      <button\n        type="button"\n        class="category-option"\n        [class.selected]="selectedCategoryId() === null"\n        (click)="selectCategory(null)"\n      >\n        Todas las categorias\n\n        @if (selectedCategoryId() === null) {\n          <ion-icon name="checkmark" />\n        }\n      </button>\n\n      @for (\n        category of categories();\n        track category.id\n      ) {\n        <button\n          type="button"\n          class="category-option"\n          [class.selected]="selectedCategoryId() === category.id"\n          (click)="selectCategory(category.id)"\n        >\n          {{ category.name }}\n\n          @if (selectedCategoryId() === category.id) {\n            <ion-icon name="checkmark" />\n          }\n        </button>\n      }\n    </div>\n\n    <ion-button\n      expand="block"\n      (click)="applyFilters()"\n    >\n      Aplicar filtros\n    </ion-button>\n  </section>\n</app-modal>\n', styles: ["/* src/app/features/tasks/components/task-filter/task-filter.component.scss */\n:host {\n  display: block;\n  color-scheme: light;\n}\n.filter-button {\n  --border-radius: 14px;\n  --border-width: 1.5px;\n  --border-color: #1769e8;\n  --color: #1769e8;\n  --background: #ffffff;\n  --background-hover: #f4f8ff;\n  min-height: 56px;\n  margin: 0;\n  font-weight: 600;\n  text-transform: none;\n}\n.filter-count {\n  display: inline-grid;\n  min-width: 24px;\n  min-height: 24px;\n  margin-left: 8px;\n  place-items: center;\n  border-radius: 999px;\n  background: #1769e8;\n  color: #ffffff;\n  font-size: 0.8rem;\n}\n.filter-content {\n  display: grid;\n  gap: 24px;\n}\n.filter-toolbar {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n  color: #667085;\n  font-size: 0.9rem;\n}\n.clear-button {\n  border: 0;\n  background: transparent;\n  color: #1769e8;\n  font: inherit;\n  font-weight: 600;\n  cursor: pointer;\n}\n.filter-section {\n  display: grid;\n  gap: 12px;\n}\n.filter-section h3 {\n  margin: 0;\n  color: #172033;\n  font-size: 1rem;\n}\n.option-grid {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 10px;\n}\n.option-button,\n.category-option {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 10px;\n  min-height: 50px;\n  padding: 0 14px;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  background: #ffffff;\n  color: #172033;\n  font: inherit;\n  text-align: left;\n  cursor: pointer;\n}\n.option-button.selected,\n.category-option.selected {\n  border-color: #1769e8;\n  background: #eef5ff;\n  color: #1769e8;\n}\n.filter-content ion-button {\n  --border-radius: 13px;\n  min-height: 50px;\n  margin: 0;\n  text-transform: none;\n}\n/*# sourceMappingURL=task-filter.component.css.map */\n"] }]
  }], () => [], { categories: [{ type: Input, args: [{ isSignal: true, alias: "categories", required: false }] }], filters: [{ type: Input, args: [{ isSignal: true, alias: "filters", required: true }] }], filterChanged: [{ type: Output, args: ["filterChanged"] }], filtersCleared: [{ type: Output, args: ["filtersCleared"] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(TaskFilterComponent, { className: "TaskFilterComponent", filePath: "app/features/tasks/components/task-filter/task-filter.component.ts", lineNumber: 46 });
})();

// src/app/features/tasks/components/task-form/task-form.component.ts
var _forTrack02 = ($index, $item) => $item.id;
function TaskFormComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-text", 3)(1, "p", 8);
    \u0275\u0275text(2, " Escribe un titulo de al menos 2 caracteres. ");
    \u0275\u0275elementEnd()();
  }
}
function TaskFormComponent_For_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-select-option", 6);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const category_r1 = ctx.$implicit;
    \u0275\u0275property("value", category_r1.id);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", category_r1.name, " ");
  }
}
var _TaskFormComponent = class _TaskFormComponent {
  constructor() {
    this.formBuilder = inject(FormBuilder);
    this.categories = input([], ...ngDevMode ? [{ debugName: "categories" }] : []);
    this.taskCreated = output();
    this.form = this.formBuilder.nonNullable.group({
      title: [
        "",
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(80)
        ]
      ],
      categoryId: [""]
    });
  }
  submit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const value = this.form.getRawValue();
    this.taskCreated.emit({
      title: value.title,
      categoryId: value.categoryId || null
    });
    this.form.reset({
      title: "",
      categoryId: ""
    });
  }
};
_TaskFormComponent.\u0275fac = function TaskFormComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _TaskFormComponent)();
};
_TaskFormComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _TaskFormComponent, selectors: [["app-task-form"]], inputs: { categories: [1, "categories"] }, outputs: { taskCreated: "taskCreated" }, decls: 12, vars: 3, consts: [[1, "task-form", 3, "ngSubmit", "formGroup"], ["lines", "none"], ["label", "Titulo", "labelPlacement", "stacked", "placeholder", "Escribe la tarea", "maxlength", "80", "formControlName", "title"], ["color", "danger"], ["label", "Categoria", "labelPlacement", "stacked", "interface", "popover", "formControlName", "categoryId"], ["value", ""], [3, "value"], ["expand", "block", "type", "submit", 3, "disabled"], [1, "validation-message"]], template: function TaskFormComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "form", 0);
    \u0275\u0275listener("ngSubmit", function TaskFormComponent_Template_form_ngSubmit_0_listener() {
      return ctx.submit();
    });
    \u0275\u0275elementStart(1, "ion-item", 1);
    \u0275\u0275element(2, "ion-input", 2);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(3, TaskFormComponent_Conditional_3_Template, 3, 0, "ion-text", 3);
    \u0275\u0275elementStart(4, "ion-item", 1)(5, "ion-select", 4)(6, "ion-select-option", 5);
    \u0275\u0275text(7, " Sin categoria ");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(8, TaskFormComponent_For_9_Template, 2, 2, "ion-select-option", 6, _forTrack02);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "ion-button", 7);
    \u0275\u0275text(11, " Crear tarea ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275property("formGroup", ctx.form);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.form.controls.title.touched && ctx.form.controls.title.invalid ? 3 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275repeater(ctx.categories());
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx.form.invalid);
  }
}, dependencies: [
  ReactiveFormsModule,
  \u0275NgNoValidate,
  NgControlStatus,
  NgControlStatusGroup,
  MaxLengthValidator,
  FormGroupDirective,
  FormControlName,
  IonButton,
  IonInput,
  IonItem,
  IonSelect,
  IonSelectOption,
  IonText
], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  color-scheme: light;\n}\n.task-form[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 14px;\n}\nion-item[_ngcontent-%COMP%] {\n  --background: #f7f9fc;\n  --color: #172033;\n  --border-radius: 14px;\n  --padding-start: 14px;\n  --inner-padding-end: 14px;\n  border: 1px solid #e2e8f0;\n}\nion-input[_ngcontent-%COMP%], \nion-select[_ngcontent-%COMP%] {\n  --color: #172033;\n  --placeholder-color: #98a2b3;\n  --label-color: #475467;\n}\nion-button[_ngcontent-%COMP%] {\n  --background: #1769e8;\n  --background-hover: #1258c7;\n  --color: #ffffff;\n  --border-radius: 13px;\n  min-height: 52px;\n  margin-top: 4px;\n  font-weight: 700;\n  text-transform: none;\n}\n.validation-message[_ngcontent-%COMP%] {\n  margin: -6px 8px 0;\n  font-size: 0.84rem;\n}\n/*# sourceMappingURL=task-form.component.css.map */"], changeDetection: 0 });
var TaskFormComponent = _TaskFormComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TaskFormComponent, [{
    type: Component,
    args: [{ selector: "app-task-form", standalone: true, imports: [
      ReactiveFormsModule,
      IonButton,
      IonInput,
      IonItem,
      IonSelect,
      IonSelectOption,
      IonText
    ], changeDetection: ChangeDetectionStrategy.OnPush, template: '<form\n  class="task-form"\n  [formGroup]="form"\n  (ngSubmit)="submit()"\n>\n  <ion-item lines="none">\n    <ion-input\n      label="Titulo"\n      labelPlacement="stacked"\n      placeholder="Escribe la tarea"\n      maxlength="80"\n      formControlName="title"\n    />\n  </ion-item>\n\n  @if (\n    form.controls.title.touched\n    && form.controls.title.invalid\n  ) {\n    <ion-text color="danger">\n      <p class="validation-message">\n        Escribe un titulo de al menos 2 caracteres.\n      </p>\n    </ion-text>\n  }\n\n  <ion-item lines="none">\n    <ion-select\n      label="Categoria"\n      labelPlacement="stacked"\n      interface="popover"\n      formControlName="categoryId"\n    >\n      <ion-select-option value="">\n        Sin categoria\n      </ion-select-option>\n\n      @for (\n        category of categories();\n        track category.id\n      ) {\n        <ion-select-option [value]="category.id">\n          {{ category.name }}\n        </ion-select-option>\n      }\n    </ion-select>\n  </ion-item>\n\n  <ion-button\n    expand="block"\n    type="submit"\n    [disabled]="form.invalid"\n  >\n    Crear tarea\n  </ion-button>\n</form>\n', styles: ["/* src/app/features/tasks/components/task-form/task-form.component.scss */\n:host {\n  display: block;\n  color-scheme: light;\n}\n.task-form {\n  display: grid;\n  gap: 14px;\n}\nion-item {\n  --background: #f7f9fc;\n  --color: #172033;\n  --border-radius: 14px;\n  --padding-start: 14px;\n  --inner-padding-end: 14px;\n  border: 1px solid #e2e8f0;\n}\nion-input,\nion-select {\n  --color: #172033;\n  --placeholder-color: #98a2b3;\n  --label-color: #475467;\n}\nion-button {\n  --background: #1769e8;\n  --background-hover: #1258c7;\n  --color: #ffffff;\n  --border-radius: 13px;\n  min-height: 52px;\n  margin-top: 4px;\n  font-weight: 700;\n  text-transform: none;\n}\n.validation-message {\n  margin: -6px 8px 0;\n  font-size: 0.84rem;\n}\n/*# sourceMappingURL=task-form.component.css.map */\n"] }]
  }], null, { categories: [{ type: Input, args: [{ isSignal: true, alias: "categories", required: false }] }], taskCreated: [{ type: Output, args: ["taskCreated"] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(TaskFormComponent, { className: "TaskFormComponent", filePath: "app/features/tasks/components/task-form/task-form.component.ts", lineNumber: 47 });
})();

// src/app/features/tasks/components/task-item/task-item.component.ts
var _TaskItemComponent = class _TaskItemComponent {
  constructor() {
    this.task = input.required(...ngDevMode ? [{ debugName: "task" }] : []);
    this.categoryName = input("Sin categoria", ...ngDevMode ? [{ debugName: "categoryName" }] : []);
    this.menuOpened = output();
    addIcons({
      checkmarkCircleOutline,
      timeOutline,
      ellipsisVertical,
      syncOutline
    });
  }
  getStatusIcon(status) {
    if (status === "in-progress") {
      return "sync-outline";
    }
    if (status === "finished") {
      return "checkmark-circle-outline";
    }
    return "time-outline";
  }
};
_TaskItemComponent.\u0275fac = function TaskItemComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _TaskItemComponent)();
};
_TaskItemComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _TaskItemComponent, selectors: [["app-task-item"]], inputs: { task: [1, "task"], categoryName: [1, "categoryName"] }, outputs: { menuOpened: "menuOpened" }, decls: 9, vars: 5, consts: [["lines", "none", 1, "task-item"], ["slot", "start", 1, "status-icon", 3, "name"], [1, "category-label"], ["slot", "end", "fill", "clear", "aria-label", "Opciones de la tarea", 3, "click"], ["slot", "icon-only", "name", "ellipsis-vertical"]], template: function TaskItemComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-item", 0);
    \u0275\u0275element(1, "ion-icon", 1);
    \u0275\u0275elementStart(2, "ion-label")(3, "h2");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 2);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "ion-button", 3);
    \u0275\u0275listener("click", function TaskItemComponent_Template_ion_button_click_7_listener() {
      return ctx.menuOpened.emit(ctx.task());
    });
    \u0275\u0275element(8, "ion-icon", 4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275classProp("finished", ctx.task().status === "finished");
    \u0275\u0275advance();
    \u0275\u0275property("name", ctx.getStatusIcon(ctx.task().status));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx.task().title);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx.categoryName(), " ");
  }
}, dependencies: [
  IonButton,
  IonIcon,
  IonItem,
  IonLabel
], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  color-scheme: light;\n}\n.task-item[_ngcontent-%COMP%] {\n  --background: var( --task-item-background, #ffffff );\n  --color: #172033;\n  --padding-start: 16px;\n  --inner-padding-end: 6px;\n  min-height: 84px;\n  border: 1px solid var(--task-group-border);\n  border-radius: 14px;\n}\n.status-icon[_ngcontent-%COMP%] {\n  color: var(--task-group-color);\n  font-size: 28px;\n}\nion-label[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0 0 8px;\n  font-size: 1rem;\n  font-weight: 650;\n  color: #172033;\n}\n.category-label[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding: 4px 9px;\n  border-radius: 999px;\n  background: color-mix(in srgb, var(--task-group-color) 13%, #ffffff);\n  color: var(--task-group-color);\n  font-size: 0.78rem;\n}\n.finished[_ngcontent-%COMP%]   ion-label[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: #7a8496;\n  text-decoration: line-through;\n}\nion-button[_ngcontent-%COMP%] {\n  --color: #667085;\n}\n/*# sourceMappingURL=task-item.component.css.map */"], changeDetection: 0 });
var TaskItemComponent = _TaskItemComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TaskItemComponent, [{
    type: Component,
    args: [{ selector: "app-task-item", standalone: true, imports: [
      IonButton,
      IonIcon,
      IonItem,
      IonLabel
    ], changeDetection: ChangeDetectionStrategy.OnPush, template: `<ion-item
  lines="none"
  class="task-item"
  [class.finished]="task().status === 'finished'"
>
  <ion-icon
    slot="start"
    class="status-icon"
    [name]="getStatusIcon(task().status)"
  />

  <ion-label>
    <h2>{{ task().title }}</h2>

    <span class="category-label">
      {{ categoryName() }}
    </span>
  </ion-label>

  <ion-button
    slot="end"
    fill="clear"
    aria-label="Opciones de la tarea"
    (click)="menuOpened.emit(task())"
  >
    <ion-icon
      slot="icon-only"
      name="ellipsis-vertical"
    />
  </ion-button>
</ion-item>
`, styles: ["/* src/app/features/tasks/components/task-item/task-item.component.scss */\n:host {\n  display: block;\n  color-scheme: light;\n}\n.task-item {\n  --background: var( --task-item-background, #ffffff );\n  --color: #172033;\n  --padding-start: 16px;\n  --inner-padding-end: 6px;\n  min-height: 84px;\n  border: 1px solid var(--task-group-border);\n  border-radius: 14px;\n}\n.status-icon {\n  color: var(--task-group-color);\n  font-size: 28px;\n}\nion-label h2 {\n  margin: 0 0 8px;\n  font-size: 1rem;\n  font-weight: 650;\n  color: #172033;\n}\n.category-label {\n  display: inline-block;\n  padding: 4px 9px;\n  border-radius: 999px;\n  background: color-mix(in srgb, var(--task-group-color) 13%, #ffffff);\n  color: var(--task-group-color);\n  font-size: 0.78rem;\n}\n.finished ion-label h2 {\n  color: #7a8496;\n  text-decoration: line-through;\n}\nion-button {\n  --color: #667085;\n}\n/*# sourceMappingURL=task-item.component.css.map */\n"] }]
  }], () => [], { task: [{ type: Input, args: [{ isSignal: true, alias: "task", required: true }] }], categoryName: [{ type: Input, args: [{ isSignal: true, alias: "categoryName", required: false }] }], menuOpened: [{ type: Output, args: ["menuOpened"] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(TaskItemComponent, { className: "TaskItemComponent", filePath: "app/features/tasks/components/task-item/task-item.component.ts", lineNumber: 39 });
})();

// src/app/features/tasks/components/task-group/task-group.component.ts
var _forTrack03 = ($index, $item) => $item.id;
function TaskGroupComponent_For_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-task-item", 8);
    \u0275\u0275listener("menuOpened", function TaskGroupComponent_For_10_Template_app_task_item_menuOpened_0_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.taskMenuOpened.emit($event));
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const task_r3 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("task", task_r3)("categoryName", ctx_r0.getCategoryName(task_r3.categoryId));
  }
}
function TaskGroupComponent_ForEmpty_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "app-empty-state", 7);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("title", ctx_r0.emptyMessage())("compact", true);
  }
}
var _TaskGroupComponent = class _TaskGroupComponent {
  constructor() {
    this.title = input.required(...ngDevMode ? [{ debugName: "title" }] : []);
    this.status = input.required(...ngDevMode ? [{ debugName: "status" }] : []);
    this.tasks = input.required(...ngDevMode ? [{ debugName: "tasks" }] : []);
    this.categories = input([], ...ngDevMode ? [{ debugName: "categories" }] : []);
    this.taskMenuOpened = output();
    this.iconName = computed(() => {
      const status = this.status();
      if (status === "in-progress") {
        return "sync-outline";
      }
      if (status === "finished") {
        return "checkmark-circle-outline";
      }
      return "time-outline";
    }, ...ngDevMode ? [{ debugName: "iconName" }] : []);
    this.emptyMessage = computed(() => {
      const status = this.status();
      if (status === "in-progress") {
        return "No hay tareas en progreso.";
      }
      if (status === "finished") {
        return "No hay tareas terminadas.";
      }
      return "No hay tareas sin iniciar.";
    }, ...ngDevMode ? [{ debugName: "emptyMessage" }] : []);
    this.categoryNames = computed(() => new Map(this.categories().map((category) => [
      category.id,
      category.name
    ])), ...ngDevMode ? [{ debugName: "categoryNames" }] : []);
    addIcons({
      checkmarkCircleOutline,
      timeOutline,
      syncOutline
    });
  }
  getCategoryName(categoryId) {
    if (!categoryId) {
      return "Sin categoria";
    }
    return this.categoryNames().get(categoryId) ?? "Sin categoria";
  }
};
_TaskGroupComponent.\u0275fac = function TaskGroupComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _TaskGroupComponent)();
};
_TaskGroupComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _TaskGroupComponent, selectors: [["app-task-group"]], inputs: { title: [1, "title"], status: [1, "status"], tasks: [1, "tasks"], categories: [1, "categories"] }, outputs: { taskMenuOpened: "taskMenuOpened" }, decls: 12, vars: 12, consts: [[3, "value"], [1, "task-group", 3, "value"], ["slot", "header", "lines", "none", 1, "group-header"], ["slot", "start", 3, "name"], [1, "group-count"], ["slot", "content", 1, "group-content"], [3, "task", "categoryName"], [3, "title", "compact"], [3, "menuOpened", "task", "categoryName"]], template: function TaskGroupComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-accordion-group", 0)(1, "ion-accordion", 1)(2, "ion-item", 2);
    \u0275\u0275element(3, "ion-icon", 3);
    \u0275\u0275elementStart(4, "ion-label");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 4);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "section", 5);
    \u0275\u0275repeaterCreate(9, TaskGroupComponent_For_10_Template, 1, 2, "app-task-item", 6, _forTrack03, false, TaskGroupComponent_ForEmpty_11_Template, 1, 2, "app-empty-state", 7);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275property("value", ctx.status());
    \u0275\u0275advance();
    \u0275\u0275classProp("not-started", ctx.status() === "not-started")("in-progress", ctx.status() === "in-progress")("finished", ctx.status() === "finished");
    \u0275\u0275property("value", ctx.status());
    \u0275\u0275advance(2);
    \u0275\u0275property("name", ctx.iconName());
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.title());
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx.tasks().length, " ");
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx.tasks());
  }
}, dependencies: [
  IonAccordion,
  IonAccordionGroup,
  IonIcon,
  IonItem,
  IonLabel,
  EmptyStateComponent,
  TaskItemComponent
], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  color-scheme: light;\n}\n.task-group[_ngcontent-%COMP%] {\n  --group-background: #fff1e6;\n  --group-border: #ffd1aa;\n  --group-color: #ef6c00;\n  --item-background: #fff8f2;\n  overflow: hidden;\n  border: 1px solid var(--group-border);\n  border-radius: 18px;\n  background: var(--group-background);\n  box-shadow: 0 6px 18px rgba(31, 55, 90, 0.06);\n}\n.task-group.in-progress[_ngcontent-%COMP%] {\n  --group-background: #eaf2ff;\n  --group-border: #c4d9ff;\n  --group-color: #1769e8;\n  --item-background: #f5f8ff;\n}\n.task-group.finished[_ngcontent-%COMP%] {\n  --group-background: #e9f8f1;\n  --group-border: #bce8d2;\n  --group-color: #0f9f63;\n  --item-background: #f4fbf7;\n}\n.group-header[_ngcontent-%COMP%] {\n  --background: var(--group-background);\n  --color: var(--group-color);\n  --min-height: 66px;\n  --padding-start: 16px;\n  --inner-padding-end: 16px;\n}\n.group-header[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: var(--group-color);\n  font-size: 25px;\n}\n.group-header[_ngcontent-%COMP%]   ion-label[_ngcontent-%COMP%] {\n  font-size: 1.05rem;\n  font-weight: 700;\n}\n.group-count[_ngcontent-%COMP%] {\n  display: inline-grid;\n  min-width: 30px;\n  min-height: 30px;\n  place-items: center;\n  border-radius: 999px;\n  background: color-mix(in srgb, var(--group-color) 13%, #ffffff);\n  color: var(--group-color);\n  font-weight: 700;\n}\n.group-content[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 7px;\n  padding: 0 7px 8px;\n  background: var(--group-background);\n  --task-group-color: var(--group-color);\n  --task-group-border: var(--group-border);\n  --task-item-background: var(--item-background);\n}\n/*# sourceMappingURL=task-group.component.css.map */"], changeDetection: 0 });
var TaskGroupComponent = _TaskGroupComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TaskGroupComponent, [{
    type: Component,
    args: [{ selector: "app-task-group", standalone: true, imports: [
      IonAccordion,
      IonAccordionGroup,
      IonIcon,
      IonItem,
      IonLabel,
      EmptyStateComponent,
      TaskItemComponent
    ], changeDetection: ChangeDetectionStrategy.OnPush, template: `<ion-accordion-group [value]="status()">
  <ion-accordion
    [value]="status()"
    class="task-group"
    [class.not-started]="status() === 'not-started'"
    [class.in-progress]="status() === 'in-progress'"
    [class.finished]="status() === 'finished'"
  >
    <ion-item
      slot="header"
      lines="none"
      class="group-header"
    >
      <ion-icon
        slot="start"
        [name]="iconName()"
      />

      <ion-label>{{ title() }}</ion-label>

      <span class="group-count">
        {{ tasks().length }}
      </span>
    </ion-item>

    <section
      slot="content"
      class="group-content"
    >
      @for (
        task of tasks();
        track task.id
      ) {
        <app-task-item
          [task]="task"
          [categoryName]="getCategoryName(task.categoryId)"
          (menuOpened)="taskMenuOpened.emit($event)"
        />
      } @empty {
        <app-empty-state
          [title]="emptyMessage()"
          [compact]="true"
        />
      }
    </section>
  </ion-accordion>
</ion-accordion-group>
`, styles: ["/* src/app/features/tasks/components/task-group/task-group.component.scss */\n:host {\n  display: block;\n  color-scheme: light;\n}\n.task-group {\n  --group-background: #fff1e6;\n  --group-border: #ffd1aa;\n  --group-color: #ef6c00;\n  --item-background: #fff8f2;\n  overflow: hidden;\n  border: 1px solid var(--group-border);\n  border-radius: 18px;\n  background: var(--group-background);\n  box-shadow: 0 6px 18px rgba(31, 55, 90, 0.06);\n}\n.task-group.in-progress {\n  --group-background: #eaf2ff;\n  --group-border: #c4d9ff;\n  --group-color: #1769e8;\n  --item-background: #f5f8ff;\n}\n.task-group.finished {\n  --group-background: #e9f8f1;\n  --group-border: #bce8d2;\n  --group-color: #0f9f63;\n  --item-background: #f4fbf7;\n}\n.group-header {\n  --background: var(--group-background);\n  --color: var(--group-color);\n  --min-height: 66px;\n  --padding-start: 16px;\n  --inner-padding-end: 16px;\n}\n.group-header ion-icon {\n  color: var(--group-color);\n  font-size: 25px;\n}\n.group-header ion-label {\n  font-size: 1.05rem;\n  font-weight: 700;\n}\n.group-count {\n  display: inline-grid;\n  min-width: 30px;\n  min-height: 30px;\n  place-items: center;\n  border-radius: 999px;\n  background: color-mix(in srgb, var(--group-color) 13%, #ffffff);\n  color: var(--group-color);\n  font-weight: 700;\n}\n.group-content {\n  display: grid;\n  gap: 7px;\n  padding: 0 7px 8px;\n  background: var(--group-background);\n  --task-group-color: var(--group-color);\n  --task-group-border: var(--group-border);\n  --task-item-background: var(--item-background);\n}\n/*# sourceMappingURL=task-group.component.css.map */\n"] }]
  }], () => [], { title: [{ type: Input, args: [{ isSignal: true, alias: "title", required: true }] }], status: [{ type: Input, args: [{ isSignal: true, alias: "status", required: true }] }], tasks: [{ type: Input, args: [{ isSignal: true, alias: "tasks", required: true }] }], categories: [{ type: Input, args: [{ isSignal: true, alias: "categories", required: false }] }], taskMenuOpened: [{ type: Output, args: ["taskMenuOpened"] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(TaskGroupComponent, { className: "TaskGroupComponent", filePath: "app/features/tasks/components/task-group/task-group.component.ts", lineNumber: 52 });
})();

// src/app/features/tasks/components/task-summary/task-summary.component.ts
var _TaskSummaryComponent = class _TaskSummaryComponent {
  constructor() {
    this.pendingCount = input.required(...ngDevMode ? [{ debugName: "pendingCount" }] : []);
    this.completedCount = input.required(...ngDevMode ? [{ debugName: "completedCount" }] : []);
    addIcons({
      checkmarkCircleOutline,
      clipboardOutline
    });
  }
};
_TaskSummaryComponent.\u0275fac = function TaskSummaryComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _TaskSummaryComponent)();
};
_TaskSummaryComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _TaskSummaryComponent, selectors: [["app-task-summary"]], inputs: { pendingCount: [1, "pendingCount"], completedCount: [1, "completedCount"] }, decls: 16, vars: 2, consts: [[1, "summary-card"], [1, "summary-item", "pending"], ["name", "clipboard-outline"], [1, "summary-divider"], [1, "summary-item", "completed"], ["name", "checkmark-circle-outline"]], template: function TaskSummaryComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 0)(1, "div", 1);
    \u0275\u0275element(2, "ion-icon", 2);
    \u0275\u0275elementStart(3, "div")(4, "strong");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span");
    \u0275\u0275text(7, "pendientes");
    \u0275\u0275elementEnd()()();
    \u0275\u0275element(8, "div", 3);
    \u0275\u0275elementStart(9, "div", 4);
    \u0275\u0275element(10, "ion-icon", 5);
    \u0275\u0275elementStart(11, "div")(12, "strong");
    \u0275\u0275text(13);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "span");
    \u0275\u0275text(15, "completadas");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx.pendingCount());
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(ctx.completedCount());
  }
}, dependencies: [IonIcon], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  color-scheme: light;\n}\n.summary-card[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 1fr 1px 1fr;\n  align-items: center;\n  min-height: 118px;\n  padding: 18px 14px;\n  border: 1px solid #e6ebf2;\n  border-radius: 22px;\n  background: #ffffff;\n  box-shadow: 0 14px 34px rgba(31, 55, 90, 0.16);\n}\n.summary-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 13px;\n}\n.summary-item[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 38px;\n}\n.summary-item[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 5px;\n}\n.summary-item[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  font-size: 1.9rem;\n  line-height: 1;\n}\n.summary-item[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #667085;\n  font-size: 0.95rem;\n}\n.pending[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%], \n.pending[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #1769e8;\n}\n.completed[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%], \n.completed[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #12a66a;\n}\n.summary-divider[_ngcontent-%COMP%] {\n  width: 1px;\n  height: 64px;\n  background: #e2e8f0;\n}\n@media (max-width: 420px) {\n  .summary-item[_ngcontent-%COMP%] {\n    gap: 8px;\n  }\n  .summary-item[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n    font-size: 31px;\n  }\n  .summary-item[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n    font-size: 1.65rem;\n  }\n  .summary-item[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n    font-size: 0.87rem;\n  }\n}\n/*# sourceMappingURL=task-summary.component.css.map */"], changeDetection: 0 });
var TaskSummaryComponent = _TaskSummaryComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TaskSummaryComponent, [{
    type: Component,
    args: [{ selector: "app-task-summary", standalone: true, imports: [IonIcon], changeDetection: ChangeDetectionStrategy.OnPush, template: '<section class="summary-card">\n  <div class="summary-item pending">\n    <ion-icon name="clipboard-outline" />\n\n    <div>\n      <strong>{{ pendingCount() }}</strong>\n      <span>pendientes</span>\n    </div>\n  </div>\n\n  <div class="summary-divider"></div>\n\n  <div class="summary-item completed">\n    <ion-icon name="checkmark-circle-outline" />\n\n    <div>\n      <strong>{{ completedCount() }}</strong>\n      <span>completadas</span>\n    </div>\n  </div>\n</section>\n', styles: ["/* src/app/features/tasks/components/task-summary/task-summary.component.scss */\n:host {\n  display: block;\n  color-scheme: light;\n}\n.summary-card {\n  display: grid;\n  grid-template-columns: 1fr 1px 1fr;\n  align-items: center;\n  min-height: 118px;\n  padding: 18px 14px;\n  border: 1px solid #e6ebf2;\n  border-radius: 22px;\n  background: #ffffff;\n  box-shadow: 0 14px 34px rgba(31, 55, 90, 0.16);\n}\n.summary-item {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 13px;\n}\n.summary-item ion-icon {\n  font-size: 38px;\n}\n.summary-item div {\n  display: grid;\n  gap: 5px;\n}\n.summary-item strong {\n  font-size: 1.9rem;\n  line-height: 1;\n}\n.summary-item span {\n  color: #667085;\n  font-size: 0.95rem;\n}\n.pending ion-icon,\n.pending strong {\n  color: #1769e8;\n}\n.completed ion-icon,\n.completed strong {\n  color: #12a66a;\n}\n.summary-divider {\n  width: 1px;\n  height: 64px;\n  background: #e2e8f0;\n}\n@media (max-width: 420px) {\n  .summary-item {\n    gap: 8px;\n  }\n  .summary-item ion-icon {\n    font-size: 31px;\n  }\n  .summary-item strong {\n    font-size: 1.65rem;\n  }\n  .summary-item span {\n    font-size: 0.87rem;\n  }\n}\n/*# sourceMappingURL=task-summary.component.css.map */\n"] }]
  }], () => [], { pendingCount: [{ type: Input, args: [{ isSignal: true, alias: "pendingCount", required: true }] }], completedCount: [{ type: Input, args: [{ isSignal: true, alias: "completedCount", required: true }] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(TaskSummaryComponent, { className: "TaskSummaryComponent", filePath: "app/features/tasks/components/task-summary/task-summary.component.ts", lineNumber: 21 });
})();

// src/app/core/feature-flags/remote-feature-flags.service.ts
var _RemoteFeatureFlagsService = class _RemoteFeatureFlagsService {
  constructor() {
    this.remoteConfig = inject(RemoteConfig, { optional: true });
    this.initialization = null;
    this.ready = false;
  }
  initialize() {
    this.initialization ??= this.loadRemoteConfig();
    return this.initialization;
  }
  readBoolean(key, fallback) {
    if (!this.ready || !this.remoteConfig) {
      return fallback;
    }
    return getBoolean(this.remoteConfig, key);
  }
  loadRemoteConfig() {
    return __async(this, null, function* () {
      try {
        if (!environment.remoteConfig.enabled || !this.remoteConfig || !(yield isSupported())) {
          return;
        }
        this.remoteConfig.defaultConfig = __spreadValues({}, environment.remoteConfig.defaultValues);
        this.remoteConfig.settings = {
          fetchTimeoutMillis: environment.remoteConfig.fetchTimeoutMillis,
          minimumFetchIntervalMillis: environment.remoteConfig.minimumFetchIntervalMillis
        };
        yield fetchAndActivate(this.remoteConfig);
      } catch {
      } finally {
        this.ready = true;
      }
    });
  }
};
_RemoteFeatureFlagsService.\u0275fac = function RemoteFeatureFlagsService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _RemoteFeatureFlagsService)();
};
_RemoteFeatureFlagsService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _RemoteFeatureFlagsService, factory: _RemoteFeatureFlagsService.\u0275fac, providedIn: "root" });
var RemoteFeatureFlagsService = _RemoteFeatureFlagsService;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RemoteFeatureFlagsService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

// src/app/features/tasks/data-access/task-feature-flags.ts
var TASK_FILTERS_ENABLED = "task_filters_enabled";
function resolveDefaultValue() {
  const value = environment.remoteConfig.defaultValues[TASK_FILTERS_ENABLED];
  return typeof value === "boolean" ? value : true;
}
var _TaskFeatureFlags = class _TaskFeatureFlags {
  constructor() {
    this.remoteFlags = inject(RemoteFeatureFlagsService);
    this.filtersEnabled = signal(resolveDefaultValue(), ...ngDevMode ? [{ debugName: "filtersEnabled" }] : []);
  }
  initialize() {
    return __async(this, null, function* () {
      yield this.remoteFlags.initialize();
      this.filtersEnabled.set(this.remoteFlags.readBoolean(TASK_FILTERS_ENABLED, resolveDefaultValue()));
    });
  }
};
_TaskFeatureFlags.\u0275fac = function TaskFeatureFlags_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _TaskFeatureFlags)();
};
_TaskFeatureFlags.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _TaskFeatureFlags, factory: _TaskFeatureFlags.\u0275fac, providedIn: "root" });
var TaskFeatureFlags = _TaskFeatureFlags;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TaskFeatureFlags, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

// src/app/features/tasks/data-access/tasks.facade.ts
var _TasksFacade = class _TasksFacade {
  constructor() {
    this.store = inject(TodoStore);
    this.loading = this.store.loading;
    this.categories = this.store.categories;
    this.filters = this.store.filters;
    this.activeFilterCount = this.store.activeFilterCount;
    this.filteredTasks = this.store.filteredTasks;
    this.notStartedTasks = this.store.notStartedTasks;
    this.inProgressTasks = this.store.inProgressTasks;
    this.finishedTasks = this.store.finishedTasks;
    this.pendingCount = this.store.pendingCount;
    this.completedCount = this.store.completedCount;
  }
  initialize() {
    return this.store.initialize();
  }
  addTask(title, categoryId) {
    return this.store.addTask(title, categoryId);
  }
  moveTask(taskId, status) {
    return this.store.moveTask(taskId, status);
  }
  deleteTask(taskId) {
    return this.store.deleteTask(taskId);
  }
  setFilters(filters) {
    this.store.setFilters(filters);
  }
  clearFilters() {
    this.store.clearFilters();
  }
};
_TasksFacade.\u0275fac = function TasksFacade_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _TasksFacade)();
};
_TasksFacade.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _TasksFacade, factory: _TasksFacade.\u0275fac, providedIn: "root" });
var TasksFacade = _TasksFacade;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TasksFacade, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

// src/app/features/tasks/pages/task-list/task-list.page.ts
function TaskListPage_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 4);
    \u0275\u0275element(1, "ion-spinner");
    \u0275\u0275elementEnd();
  }
}
function TaskListPage_Conditional_5_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-task-filter", 24);
    \u0275\u0275listener("filterChanged", function TaskListPage_Conditional_5_Conditional_4_Template_app_task_filter_filterChanged_0_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.setFilters($event));
    })("filtersCleared", function TaskListPage_Conditional_5_Conditional_4_Template_app_task_filter_filtersCleared_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.facade.clearFilters());
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275property("categories", ctx_r1.facade.categories())("filters", ctx_r1.facade.filters());
  }
}
function TaskListPage_Conditional_5_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-task-group", 25);
    \u0275\u0275listener("taskMenuOpened", function TaskListPage_Conditional_5_Conditional_6_Template_app_task_group_taskMenuOpened_0_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openTaskActions($event));
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275property("tasks", ctx_r1.facade.notStartedTasks())("categories", ctx_r1.facade.categories());
  }
}
function TaskListPage_Conditional_5_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-task-group", 26);
    \u0275\u0275listener("taskMenuOpened", function TaskListPage_Conditional_5_Conditional_7_Template_app_task_group_taskMenuOpened_0_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openTaskActions($event));
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275property("tasks", ctx_r1.facade.inProgressTasks())("categories", ctx_r1.facade.categories());
  }
}
function TaskListPage_Conditional_5_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-task-group", 27);
    \u0275\u0275listener("taskMenuOpened", function TaskListPage_Conditional_5_Conditional_8_Template_app_task_group_taskMenuOpened_0_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openTaskActions($event));
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275property("tasks", ctx_r1.facade.finishedTasks())("categories", ctx_r1.facade.categories());
  }
}
function TaskListPage_Conditional_5_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 23);
    \u0275\u0275element(1, "app-empty-state", 28);
    \u0275\u0275elementEnd();
  }
}
function TaskListPage_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "main", 5)(1, "section", 15)(2, "aside", 16);
    \u0275\u0275element(3, "app-task-summary", 17);
    \u0275\u0275conditionalCreate(4, TaskListPage_Conditional_5_Conditional_4_Template, 1, 2, "app-task-filter", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "section", 19);
    \u0275\u0275conditionalCreate(6, TaskListPage_Conditional_5_Conditional_6_Template, 1, 2, "app-task-group", 20);
    \u0275\u0275conditionalCreate(7, TaskListPage_Conditional_5_Conditional_7_Template, 1, 2, "app-task-group", 21);
    \u0275\u0275conditionalCreate(8, TaskListPage_Conditional_5_Conditional_8_Template, 1, 2, "app-task-group", 22);
    \u0275\u0275conditionalCreate(9, TaskListPage_Conditional_5_Conditional_9_Template, 2, 0, "section", 23);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275property("pendingCount", ctx_r1.facade.pendingCount())("completedCount", ctx_r1.facade.completedCount());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.filtersEnabled() ? 4 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.showNotStartedGroup() ? 6 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.showInProgressGroup() ? 7 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.showFinishedGroup() ? 8 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.hasActiveFilters() && !ctx_r1.hasFilteredTasks() ? 9 : -1);
  }
}
var _TaskListPage = class _TaskListPage {
  constructor() {
    this.facade = inject(TasksFacade);
    this.featureFlags = inject(TaskFeatureFlags);
    this.filtersEnabled = this.featureFlags.filtersEnabled;
    this.selectedTask = signal(null, ...ngDevMode ? [{ debugName: "selectedTask" }] : []);
    this.taskFormOpen = signal(false, ...ngDevMode ? [{ debugName: "taskFormOpen" }] : []);
    this.toastOpen = signal(false, ...ngDevMode ? [{ debugName: "toastOpen" }] : []);
    this.toastMessage = signal("", ...ngDevMode ? [{ debugName: "toastMessage" }] : []);
    this.hasActiveFilters = computed(() => this.facade.activeFilterCount() > 0, ...ngDevMode ? [{ debugName: "hasActiveFilters" }] : []);
    this.hasFilteredTasks = computed(() => this.facade.filteredTasks().length > 0, ...ngDevMode ? [{ debugName: "hasFilteredTasks" }] : []);
    this.showNotStartedGroup = computed(() => !this.hasActiveFilters() || this.facade.notStartedTasks().length > 0, ...ngDevMode ? [{ debugName: "showNotStartedGroup" }] : []);
    this.showInProgressGroup = computed(() => !this.hasActiveFilters() || this.facade.inProgressTasks().length > 0, ...ngDevMode ? [{ debugName: "showInProgressGroup" }] : []);
    this.showFinishedGroup = computed(() => !this.hasActiveFilters() || this.facade.finishedTasks().length > 0, ...ngDevMode ? [{ debugName: "showFinishedGroup" }] : []);
    addIcons({ add });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      yield Promise.all([
        this.facade.initialize(),
        this.featureFlags.initialize()
      ]);
      if (!this.filtersEnabled()) {
        this.facade.clearFilters();
      }
    });
  }
  openTaskForm() {
    this.taskFormOpen.set(true);
  }
  closeTaskForm() {
    this.taskFormOpen.set(false);
  }
  createTask(input2) {
    return __async(this, null, function* () {
      try {
        yield this.facade.addTask(input2.title, input2.categoryId);
        this.closeTaskForm();
      } catch (error) {
        this.showError(error);
      }
    });
  }
  setFilters(filters) {
    if (!this.filtersEnabled()) {
      return;
    }
    try {
      this.facade.setFilters(filters);
    } catch (error) {
      this.showError(error);
    }
  }
  openTaskActions(task) {
    this.selectedTask.set(task);
  }
  closeTaskActions() {
    this.selectedTask.set(null);
  }
  moveSelectedTask(status) {
    return __async(this, null, function* () {
      const task = this.selectedTask();
      if (!task) {
        return;
      }
      try {
        yield this.facade.moveTask(task.id, status);
        this.closeTaskActions();
      } catch (error) {
        this.showError(error);
      }
    });
  }
  deleteSelectedTask() {
    return __async(this, null, function* () {
      const task = this.selectedTask();
      if (!task) {
        return;
      }
      try {
        yield this.facade.deleteTask(task.id);
        this.closeTaskActions();
      } catch (error) {
        this.showError(error);
      }
    });
  }
  showError(error) {
    this.toastMessage.set(error instanceof Error ? error.message : "No fue posible completar la operacion.");
    this.toastOpen.set(true);
  }
};
_TaskListPage.\u0275fac = function TaskListPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _TaskListPage)();
};
_TaskListPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _TaskListPage, selectors: [["app-task-list"]], decls: 16, vars: 8, consts: [[1, "page-header"], [1, "page-header-toolbar"], ["title", "To-Do"], [1, "page-content"], [1, "loading"], [1, "page-shell"], ["vertical", "bottom", "horizontal", "end", "slot", "fixed"], ["aria-label", "Crear tarea", 3, "click"], ["name", "add"], ["title", "Nueva tarea", "description", "Agrega el titulo y una categoria.", 3, "closed", "open"], [3, "taskCreated", "categories"], [3, "moved", "deleted", "closed", "task", "open"], ["position", "bottom", 3, "didDismiss", "isOpen", "message", "duration"], [1, "page-footer"], [1, "page-footer-toolbar"], [1, "tasks-layout"], [1, "tasks-sidebar"], [3, "pendingCount", "completedCount"], [3, "categories", "filters"], [1, "task-groups"], ["title", "No iniciado", "status", "not-started", 3, "tasks", "categories"], ["title", "En progreso", "status", "in-progress", 3, "tasks", "categories"], ["title", "Terminado", "status", "finished", 3, "tasks", "categories"], [1, "filtered-empty-state"], [3, "filterChanged", "filtersCleared", "categories", "filters"], ["title", "No iniciado", "status", "not-started", 3, "taskMenuOpened", "tasks", "categories"], ["title", "En progreso", "status", "in-progress", 3, "taskMenuOpened", "tasks", "categories"], ["title", "Terminado", "status", "finished", 3, "taskMenuOpened", "tasks", "categories"], ["title", "No hay resultados", "message", "Prueba cambiando o eliminando los filtros."]], template: function TaskListPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1);
    \u0275\u0275element(2, "app-header", 2);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(3, "ion-content", 3);
    \u0275\u0275conditionalCreate(4, TaskListPage_Conditional_4_Template, 2, 0, "div", 4)(5, TaskListPage_Conditional_5_Template, 10, 7, "main", 5);
    \u0275\u0275elementStart(6, "ion-fab", 6)(7, "ion-fab-button", 7);
    \u0275\u0275listener("click", function TaskListPage_Template_ion_fab_button_click_7_listener() {
      return ctx.openTaskForm();
    });
    \u0275\u0275element(8, "ion-icon", 8);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "app-modal", 9);
    \u0275\u0275listener("closed", function TaskListPage_Template_app_modal_closed_9_listener() {
      return ctx.closeTaskForm();
    });
    \u0275\u0275elementStart(10, "app-task-form", 10);
    \u0275\u0275listener("taskCreated", function TaskListPage_Template_app_task_form_taskCreated_10_listener($event) {
      return ctx.createTask($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "app-task-actions", 11);
    \u0275\u0275listener("moved", function TaskListPage_Template_app_task_actions_moved_11_listener($event) {
      return ctx.moveSelectedTask($event);
    })("deleted", function TaskListPage_Template_app_task_actions_deleted_11_listener() {
      return ctx.deleteSelectedTask();
    })("closed", function TaskListPage_Template_app_task_actions_closed_11_listener() {
      return ctx.closeTaskActions();
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "ion-toast", 12);
    \u0275\u0275listener("didDismiss", function TaskListPage_Template_ion_toast_didDismiss_12_listener() {
      return ctx.toastOpen.set(false);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "ion-footer", 13)(14, "ion-toolbar", 14);
    \u0275\u0275element(15, "app-bottom-navigation");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.facade.loading() ? 4 : 5);
    \u0275\u0275advance(5);
    \u0275\u0275property("open", ctx.taskFormOpen());
    \u0275\u0275advance();
    \u0275\u0275property("categories", ctx.facade.categories());
    \u0275\u0275advance();
    \u0275\u0275property("task", ctx.selectedTask())("open", ctx.selectedTask() !== null);
    \u0275\u0275advance();
    \u0275\u0275property("isOpen", ctx.toastOpen())("message", ctx.toastMessage())("duration", 2600);
  }
}, dependencies: [
  IonContent,
  IonFab,
  IonFabButton,
  IonFooter,
  IonHeader,
  IonIcon,
  IonSpinner,
  IonToast,
  IonToolbar,
  AppHeaderComponent,
  AppModalComponent,
  BottomNavigationComponent,
  EmptyStateComponent,
  TaskActionsComponent,
  TaskFilterComponent,
  TaskFormComponent,
  TaskGroupComponent,
  TaskSummaryComponent
], styles: ["\n\n[_nghost-%COMP%] {\n  --task-page-background: #f5f7fb;\n  --task-page-text: #172033;\n  --task-page-muted: #667085;\n}\n.page-header[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      var(--app-header-start),\n      var(--app-header-end));\n  box-shadow: 0 5px 18px rgba(20, 74, 150, 0.16);\n}\n.page-header-toolbar[_ngcontent-%COMP%] {\n  --background: transparent;\n  --border-width: 0;\n  --min-height: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n}\n.page-footer[_ngcontent-%COMP%] {\n  background: #ffffff;\n}\n.page-footer-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  --border-width: 0;\n  --min-height: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n  border-top: 1px solid #e2e8f0;\n  box-shadow: 0 -6px 20px rgba(31, 55, 90, 0.08);\n}\n.page-content[_ngcontent-%COMP%] {\n  --background: var(--task-page-background);\n  --color: var(--task-page-text);\n  --padding-top: 0;\n  --padding-bottom: 20px;\n}\n.page-shell[_ngcontent-%COMP%] {\n  width: min(100% - 24px, 1120px);\n  margin: 0 auto;\n  padding: 22px 0 100px;\n}\n.tasks-layout[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 22px;\n}\n.tasks-sidebar[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 18px;\n}\n.task-groups[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 18px;\n}\n.filtered-empty-state[_ngcontent-%COMP%] {\n  overflow: hidden;\n  border: 1px solid #e2e8f0;\n  border-radius: 18px;\n  background: #ffffff;\n  box-shadow: 0 6px 18px rgba(31, 55, 90, 0.06);\n}\n.loading[_ngcontent-%COMP%] {\n  display: grid;\n  min-height: 60vh;\n  place-items: center;\n}\nion-fab[_ngcontent-%COMP%] {\n  margin: 0 10px 14px 0;\n}\nion-fab-button[_ngcontent-%COMP%] {\n  --background: #1769e8;\n  --color: #ffffff;\n  --box-shadow: 0 10px 24px rgb(23 105 232 / 32%);\n}\n@media (min-width: 900px) {\n  .page-shell[_ngcontent-%COMP%] {\n    padding-top: 28px;\n  }\n  .tasks-layout[_ngcontent-%COMP%] {\n    grid-template-columns: 300px minmax(0, 1fr);\n    align-items: start;\n  }\n  .tasks-sidebar[_ngcontent-%COMP%] {\n    position: sticky;\n    top: 24px;\n  }\n  ion-fab[_ngcontent-%COMP%] {\n    margin-right: max(18px, (100vw - 1120px) / 2);\n  }\n}\n/*# sourceMappingURL=task-list.page.css.map */"], changeDetection: 0 });
var TaskListPage = _TaskListPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TaskListPage, [{
    type: Component,
    args: [{ selector: "app-task-list", standalone: true, imports: [
      IonContent,
      IonFab,
      IonFabButton,
      IonFooter,
      IonHeader,
      IonIcon,
      IonSpinner,
      IonToast,
      IonToolbar,
      AppHeaderComponent,
      AppModalComponent,
      BottomNavigationComponent,
      EmptyStateComponent,
      TaskActionsComponent,
      TaskFilterComponent,
      TaskFormComponent,
      TaskGroupComponent,
      TaskSummaryComponent
    ], changeDetection: ChangeDetectionStrategy.OnPush, template: '<ion-header class="page-header">\n  <ion-toolbar class="page-header-toolbar">\n    <app-header title="To-Do" />\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class="page-content">\n  @if (facade.loading()) {\n    <div class="loading">\n      <ion-spinner />\n    </div>\n  } @else {\n    <main class="page-shell">\n      <section class="tasks-layout">\n        <aside class="tasks-sidebar">\n          <app-task-summary\n            [pendingCount]="facade.pendingCount()"\n            [completedCount]="facade.completedCount()"\n          />\n\n          @if (filtersEnabled()) {\n            <app-task-filter\n              [categories]="facade.categories()"\n              [filters]="facade.filters()"\n              (filterChanged)="setFilters($event)"\n              (filtersCleared)="facade.clearFilters()"\n            />\n          }\n        </aside>\n\n        <section class="task-groups">\n          @if (showNotStartedGroup()) {\n            <app-task-group\n              title="No iniciado"\n              status="not-started"\n              [tasks]="facade.notStartedTasks()"\n              [categories]="facade.categories()"\n              (taskMenuOpened)="openTaskActions($event)"\n            />\n          }\n\n          @if (showInProgressGroup()) {\n            <app-task-group\n              title="En progreso"\n              status="in-progress"\n              [tasks]="facade.inProgressTasks()"\n              [categories]="facade.categories()"\n              (taskMenuOpened)="openTaskActions($event)"\n            />\n          }\n\n          @if (showFinishedGroup()) {\n            <app-task-group\n              title="Terminado"\n              status="finished"\n              [tasks]="facade.finishedTasks()"\n              [categories]="facade.categories()"\n              (taskMenuOpened)="openTaskActions($event)"\n            />\n          }\n\n          @if (\n            hasActiveFilters()\n            && !hasFilteredTasks()\n          ) {\n            <section class="filtered-empty-state">\n              <app-empty-state\n                title="No hay resultados"\n                message="Prueba cambiando o eliminando los filtros."\n              />\n            </section>\n          }\n        </section>\n      </section>\n    </main>\n  }\n\n  <ion-fab\n    vertical="bottom"\n    horizontal="end"\n    slot="fixed"\n  >\n    <ion-fab-button\n      aria-label="Crear tarea"\n      (click)="openTaskForm()"\n    >\n      <ion-icon name="add" />\n    </ion-fab-button>\n  </ion-fab>\n\n  <app-modal\n    [open]="taskFormOpen()"\n    title="Nueva tarea"\n    description="Agrega el titulo y una categoria."\n    (closed)="closeTaskForm()"\n  >\n    <app-task-form\n      [categories]="facade.categories()"\n      (taskCreated)="createTask($event)"\n    />\n  </app-modal>\n\n  <app-task-actions\n    [task]="selectedTask()"\n    [open]="selectedTask() !== null"\n    (moved)="moveSelectedTask($event)"\n    (deleted)="deleteSelectedTask()"\n    (closed)="closeTaskActions()"\n  />\n\n  <ion-toast\n    [isOpen]="toastOpen()"\n    [message]="toastMessage()"\n    [duration]="2600"\n    position="bottom"\n    (didDismiss)="toastOpen.set(false)"\n  />\n</ion-content>\n\n<ion-footer class="page-footer">\n  <ion-toolbar class="page-footer-toolbar">\n    <app-bottom-navigation />\n  </ion-toolbar>\n</ion-footer>\n', styles: ["/* src/app/features/tasks/pages/task-list/task-list.page.scss */\n:host {\n  --task-page-background: #f5f7fb;\n  --task-page-text: #172033;\n  --task-page-muted: #667085;\n}\n.page-header {\n  background:\n    linear-gradient(\n      135deg,\n      var(--app-header-start),\n      var(--app-header-end));\n  box-shadow: 0 5px 18px rgba(20, 74, 150, 0.16);\n}\n.page-header-toolbar {\n  --background: transparent;\n  --border-width: 0;\n  --min-height: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n}\n.page-footer {\n  background: #ffffff;\n}\n.page-footer-toolbar {\n  --background: #ffffff;\n  --border-width: 0;\n  --min-height: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n  border-top: 1px solid #e2e8f0;\n  box-shadow: 0 -6px 20px rgba(31, 55, 90, 0.08);\n}\n.page-content {\n  --background: var(--task-page-background);\n  --color: var(--task-page-text);\n  --padding-top: 0;\n  --padding-bottom: 20px;\n}\n.page-shell {\n  width: min(100% - 24px, 1120px);\n  margin: 0 auto;\n  padding: 22px 0 100px;\n}\n.tasks-layout {\n  display: grid;\n  gap: 22px;\n}\n.tasks-sidebar {\n  display: grid;\n  gap: 18px;\n}\n.task-groups {\n  display: grid;\n  gap: 18px;\n}\n.filtered-empty-state {\n  overflow: hidden;\n  border: 1px solid #e2e8f0;\n  border-radius: 18px;\n  background: #ffffff;\n  box-shadow: 0 6px 18px rgba(31, 55, 90, 0.06);\n}\n.loading {\n  display: grid;\n  min-height: 60vh;\n  place-items: center;\n}\nion-fab {\n  margin: 0 10px 14px 0;\n}\nion-fab-button {\n  --background: #1769e8;\n  --color: #ffffff;\n  --box-shadow: 0 10px 24px rgb(23 105 232 / 32%);\n}\n@media (min-width: 900px) {\n  .page-shell {\n    padding-top: 28px;\n  }\n  .tasks-layout {\n    grid-template-columns: 300px minmax(0, 1fr);\n    align-items: start;\n  }\n  .tasks-sidebar {\n    position: sticky;\n    top: 24px;\n  }\n  ion-fab {\n    margin-right: max(18px, (100vw - 1120px) / 2);\n  }\n}\n/*# sourceMappingURL=task-list.page.css.map */\n"] }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(TaskListPage, { className: "TaskListPage", filePath: "app/features/tasks/pages/task-list/task-list.page.ts", lineNumber: 92 });
})();
export {
  TaskListPage
};
//# sourceMappingURL=task-list.page-PMVCTTII.js.map
